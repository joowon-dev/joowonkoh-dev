// 렌더러. 캔버스를 잡고, 글자 마스크를 만들고, 고정 타임스텝으로 월드를 돌리고,
// 그리고, 소리를 낸다. 셸(맥/윈도우)이 주는 window.sneaky 로 핫키를 받는다.

import { DT } from '../show/constants.js'
import {
  createWorld, stepWorld, resizeWorld, restartWorld, setShow, launchNow, drainSounds,
} from '../show/engine.js'
import { TEMPLATES, DEFAULT_TEMPLATE, PALETTE, collectTexts } from '../show/script.js'
import { cropMask, liftMask, removeFlatBackground, sampleImageMask } from '../show/shapes.js'
import { makeRng } from '../show/rng.js'
import { paletteFor, planPlaylist, planCountdown, countdownLead } from '../show/playlist.js'
import { draw } from '../render/draw.js'
import { createAudio } from './audio.js'

const canvas = document.getElementById('stage')
const ctx = canvas.getContext('2d', { alpha: true })

/** 안내를 몇 초 띄우고 몇 초에 걸쳐 지울지. */
const HINT_SHOW = 6
const HINT_FADE = 1.5

/**
 * 이미지 마스크를 만들 때 줄이는 긴 변의 길이(px).
 *
 * 점을 IMAGE_COUNT 개만 뽑으므로 이보다 잘아 봐야 보이지 않는다. 셸도 넘기기 전에 같은
 * 크기로 줄이는데, 브라우저에서 직접 큰 이미지를 던져 넣을 때를 위해 여기서도 줄인다.
 */
const IMAGE_MAX = 512

/**
 * 이미지 한 발에 쓰는 점의 수. **점이 곧 해상도다.**
 *
 * 1800 개는 512×512 이미지를 42×42 격자로 줄여 보는 셈이라 그림이 뭉개졌다. 18000 이면
 * 134×134 격자다.
 *
 * **크게 띄우려면 그만큼 점이 더 든다.** 화면에서 점 사이 간격이 그림의 가는 선보다
 * 벌어지면 선이 점 사이 빈틈에 묻혀 안 읽힌다 — 9000 개로 화면의 80% 를 채웠더니
 * 작게 띄웠을 때보다 오히려 못 읽혔다. 재 보니 18000 개가 프레임당 7.7ms, 30000 개가
 * 12.8ms 다(예산 16.7ms). 30000 은 너무 아슬아슬해서 18000 에서 멈췄다.
 */
const IMAGE_COUNT = 18000

/** 이미지 한 발이 화면의 몇 %를 차지하나. 가로·세로 중 빡빡한 쪽에 맞춘다(engine 의 fit). */
const IMAGE_FIT = 0.8

/**
 * 이미지가 모양을 유지하는 시간(초). 글자의 TEXT_HOLD(1.9)보다 길다 —
 * 글자는 읽으면 끝이지만 그림은 뜯어보게 된다.
 */
const IMAGE_HOLD = 3.4

/**
 * 단색 배경을 지울지. **기본은 안 지운다** — 올린 그림이 그대로 보이는 편이 낫다는
 * 주인의 결정이다. 켜면 `removeFlatBackground()` 가 테두리에 이어진 배경색을 지워
 * 실루엣만 남긴다(로고·캐릭터 아트에서 잘 듣는다).
 */
const CUT_BACKGROUND = false

/**
 * 이미지 점 하나의 굵기. 글자(2.3~2.6)보다 가늘다.
 *
 * 글자는 굵어야 획이 이어져 읽히지만, 이미지는 **빈 자리가 곧 그림**이다 — 눈·코·윤곽선은
 * 빛이 없는 자리로 나타나므로, 점이 굵고 빛무리가 크면 그 자리가 메워져 통째로 뭉갠다.
 * 2.2 로는 얼굴이 뭉개졌고 1.6 에서 사과·귀·가방이 또렷해졌다.
 */
const IMAGE_SIZE = 1.6

/**
 * 들고 있을 이미지 마스크의 수.
 *
 * 올라가는 중인 포탄이 마스크 키를 들고 있으므로(2 초쯤) 바로 지우면 그 발이 조용히
 * 안 터진다. 보관함 목록을 통째로 다시 쏠 때 다시 만들지 않을 만큼은 남겨 둔다 —
 * 그렇다고 무한히 쌓으면 한 장에 2MB 남짓이 계속 쌓인다.
 */
const IMAGE_KEEP = 24

/** 이미지 점 배치를 뽑을 때 쓰는 시드. 고정이라 같은 이미지는 늘 같게 뜬다. */
const IMAGE_SEED = 20260907

/** 카운트다운 숫자 사이의 간격(초). 초를 세는 것이니 1 초다. */
const COUNT_STEP = 1.0

/**
 * 카운트다운 숫자의 터짐 사양.
 *
 * `life` 가 유난히 짧다(1.0). 글자 기본값(TEXT_HOLD + 2 = 3.9)을 쓰면 숫자 셋이 한꺼번에
 * 겹쳐 떠서 카운트다운이 아니라 뒤엉킨 숫자 더미가 된다 — 다음 숫자가 뜨기 전에 사라져야
 * 세는 것으로 보인다.
 */
const COUNT_BURST = {
  textHeight: 0.26,
  count: 900,
  size: 2.6,
  // 한 박자(COUNT_STEP) 안에 뜨고 사그라들어야 한다. 이보다 길면 다음 숫자와, 그리고
  // 마지막에는 이미지와 겹친다 — 겹치지 않으려고 이미지를 미뤘더니 그 빈 시간이
  // 「끝났는데 아무 일도 안 일어나는」 1.8 초가 됐다. 미루는 대신 숫자를 짧게 한다.
  life: 1.0,
  hold: 0.45,
  colors: ['#ffd76a', '#ffb43d', '#fff3c4', '#ffffff'],
}

/**
 * 글자를 픽셀로 바꾼다. 캔버스가 필요한 일이라 순수 모듈이 아니라 여기서 한다.
 *
 * 굵은 글씨로 크게 그린 다음 알파 채널만 뽑아 낸다. 한글·이모지 모두, 폰트가 그릴 수
 * 있으면 그대로 마스크가 된다.
 *
 * @returns {{data: Uint8Array, width: number, height: number}}
 */
function buildMask(text, fontSize = 180) {
  // 로마자는 세리프로, 한글은 고딕으로 뽑는다. 폰트 대체는 **글자 단위**로 일어나므로
  // 앞에 세리프를 두면 「I LOVE YOU」만 세리프가 되고 「사랑해」는 뒤의 고딕이 그린다.
  //
  // 세리프여야 하는 이유는 대문자 I 하나 때문이다. 산세리프의 I 는 획이 하나뿐이라
  // 불꽃으로 세우면 글자가 아니라 그냥 막대기로 보인다 — 가로획이 있어야 I 로 읽힌다.
  const family = 'Georgia, "Times New Roman", "Apple SD Gothic Neo", "Malgun Gothic", serif'
  const font = `800 ${fontSize}px ${family}`

  // 폭을 재려면 컨텍스트가 하나 있어야 하고, 캔버스 크기를 바꾸면 컨텍스트 상태가
  // 초기화되므로 잰 다음 다시 폰트를 넣는다.
  const measure = document.createElement('canvas').getContext('2d')
  measure.font = font
  const width = Math.max(8, Math.ceil(measure.measureText(text).width) + fontSize * 0.3)
  const height = Math.ceil(fontSize * 1.35)

  const off = document.createElement('canvas')
  off.width = width
  off.height = height
  const octx = off.getContext('2d')
  octx.font = font
  octx.textAlign = 'center'
  octx.textBaseline = 'middle'
  octx.fillStyle = '#fff'
  octx.fillText(text, width / 2, height / 2)

  const pixels = octx.getImageData(0, 0, width, height).data
  const data = new Uint8Array(width * height)
  for (let i = 0; i < data.length; i += 1) data[i] = pixels[i * 4 + 3]

  return cropMask({ data, width, height })
}

/**
 * 이미지를 **색까지 든** 마스크로 바꾼다.
 *
 * 알파는 글자와 같은 자리(`data`)에, RGB 는 `rgb`(픽셀당 세 칸)에 담는다. 순수 모듈의
 * `sampleMask()` 가 `rgb` 를 보면 점마다 그 픽셀의 색을 같이 돌려주고, 그래서 이미지가
 * 원본 색으로 터진다.
 *
 * 투명 PNG 는 알파가 그대로라 오려진 모양만 터진다. 투명도가 없는 그림은
 * `removeFlatBackground()` 가 단색 배경을 지워서 실루엣으로 만든다 — 안 지우면 배경까지
 * 통째로 켜져서 네모난 빛덩어리가 되고 주인공이 묻힌다. 테두리가 제각각인 사진은 거의
 * 안 지워지고 사각형 점묘화 그대로다.
 *
 * **밝기로 실루엣을 따지는 않는다.** 사진마다 결과가 달라 예측이 안 된다 —
 * 배경 지우기는 「테두리에 이어진 같은 색」이라는 규칙이 분명해서 예측이 된다.
 *
 * @param {string} src data URL 이나 이미지 주소
 * @returns {Promise<{data: Uint8Array, width: number, height: number, rgb: Uint8Array}>}
 */
function buildImageMask(src) {
  return new Promise((resolve, reject) => {
    const image = new Image()
    image.onload = () => {
      try {
        resolve(maskFromImage(image))
      } catch (error) {
        reject(error)
      }
    }
    image.onerror = () => reject(new Error('이미지를 읽지 못했다'))
    image.src = src
  })
}

function maskFromImage(image) {
  const source = Math.max(image.naturalWidth || image.width, image.naturalHeight || image.height)
  const scale = source > IMAGE_MAX ? IMAGE_MAX / source : 1
  const width = Math.max(1, Math.round((image.naturalWidth || image.width) * scale))
  const height = Math.max(1, Math.round((image.naturalHeight || image.height) * scale))

  const off = document.createElement('canvas')
  off.width = width
  off.height = height
  const octx = off.getContext('2d')
  octx.drawImage(image, 0, 0, width, height)

  const pixels = octx.getImageData(0, 0, width, height).data
  const data = new Uint8Array(width * height)
  const rgb = new Uint8Array(width * height * 3)
  for (let i = 0; i < data.length; i += 1) {
    data[i] = pixels[i * 4 + 3]
    rgb[i * 3] = pixels[i * 4]
    rgb[i * 3 + 1] = pixels[i * 4 + 1]
    rgb[i * 3 + 2] = pixels[i * 4 + 2]
  }
  // 배경을 지운다면 **자르기 전에** 지워야 crop 이 주인공에 맞춰 잘린다 — 나중에
  // 지우면 마스크 크기가 이미 배경 여백에 좌우된 뒤다.
  const raw = { data, width, height, rgb }
  const cut = CUT_BACKGROUND ? removeFlatBackground(raw) : raw
  // 어두운 픽셀은 가산 합성에서 아예 안 보인다. 그늘만 들어 올린다.
  const mask = liftMask(cropMask(cut))

  // 점을 **여기서** 뽑아 둔다. 512×512 에서 18000 점을 뽑는 데 40ms 가 걸려서, 터지는
  // 순간에 하면 네 프레임이 멈춘다. 좌표가 화면 크기와 무관하게 정규화돼 있어 미리
  // 뽑아 둘 수 있다. 이 순간은 파일 선택창을 닫은 직후라 멈춰도 눈에 안 띈다.
  //
  // 시드를 고정한 난수를 쓴다 — 같은 이미지는 언제나 같은 점 배치로 뜬다.
  mask.points = sampleImageMask(mask, IMAGE_COUNT, makeRng(IMAGE_SEED))
  return mask
}

function buildMasks(texts) {
  const masks = {}
  for (const text of texts) {
    try {
      masks[text] = buildMask(text)
    } catch (error) {
      // 마스크를 못 만들어도 쇼는 계속돼야 한다 — 그 큐만 조용히 건너뛴다.
      console.error(`글자 마스크 실패: ${text} — ${error}`)
    }
  }
  return masks
}

/** 캔버스를 화면 크기에 맞춘다. 레티나에서는 실제 픽셀이 두 배다. */
function fit(world) {
  const dpr = Math.min(window.devicePixelRatio || 1, 2)
  const width = Math.max(1, Math.round(window.innerWidth))
  const height = Math.max(1, Math.round(window.innerHeight))
  canvas.width = Math.round(width * dpr)
  canvas.height = Math.round(height * dpr)
  canvas.style.width = `${width}px`
  canvas.style.height = `${height}px`
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
  if (world) resizeWorld(world, width, height)
  return { width, height, dpr }
}

// 안내가 뜬 지 얼마나 됐나. 쇼를 다시 시작하거나 템플릿을 바꾸면 0 으로 돌아간다.
// (선언이 여기 있는 것은 아래 applyTemplate() 이 이걸 만지기 때문이다.)
let hintTime = 0

/** 지금 도는 템플릿의 키. 셸이 기억해 두었다가 다음에 켤 때 돌려준다. */
let templateKey = DEFAULT_TEMPLATE

/** 지금 템플릿의 글자 마스크. 템플릿을 바꾸면 통째로 바뀐다. */
let textMasks = buildMasks(collectTexts(TEMPLATES[DEFAULT_TEMPLATE].script))

/**
 * 이미지 마스크. 글자 마스크와 따로 들고 있어야 한다 — 템플릿을 바꿔도 방금 던져 넣은
 * 이미지가 사라지면 안 되기 때문이다. 엔진에는 둘을 합쳐서 준다.
 *
 * 키는 **항목 id** 다(보관함 항목이든, 메뉴에서 바로 쏜 한 장이든). 그래서 같은 항목을
 * 다시 쏠 때 100ms 짜리 마스크 만들기를 되풀이하지 않는다.
 */
const imageMasks = new Map()
let imageCount = 0

/**
 * 카운트다운을 몇 초부터 셀지. 0 이면 안 센다. 셸이 기억해 두었다가 다음에 켤 때 준다.
 */
let countdown = 0

/** 카운트다운 숫자의 글자 마스크. 쓰는 숫자만 만들어 두고 재사용한다. */
const countMasks = {}


const size = fit(null)
const world = createWorld({
  width: size.width,
  height: size.height,
  script: TEMPLATES[DEFAULT_TEMPLATE].script,
  masks: { ...textMasks },
})

/** 엔진이 보는 마스크는 글자 + 이미지다. 어느 쪽이 바뀌든 이걸로 다시 맞춘다. */
function syncMasks() {
  world.masks = { ...textMasks, ...countMasks, ...Object.fromEntries(imageMasks) }
}

/** 카운트다운에 쓸 숫자 마스크를 만들어 둔다. 이미 있으면 그냥 둔다. */
function ensureCountMasks(from) {
  for (let n = from; n >= 1; n -= 1) {
    const text = String(n)
    if (countMasks[text]) continue
    try {
      countMasks[text] = buildMask(text)
    } catch (error) {
      console.error(`숫자 마스크 실패: ${text} — ${error}`)
    }
  }
}

/** 쇼 템플릿을 갈아 끼운다. 모르는 키가 오면 기본으로 돌아간다. */
function applyTemplate(key) {
  const template = TEMPLATES[key]
  if (!template) {
    console.error(`모르는 템플릿: ${key}`)
    return
  }
  templateKey = key
  textMasks = buildMasks(collectTexts(template.script))
  setShow(world, template.script, {})
  syncMasks()
  hintTime = 0
}

/**
 * 이미지 한 장을 바로 한 발. 메뉴바 「이미지로 불꽃…」 과 ⌥⇧I 가 이 길로 온다.
 *
 * 보관함 목록과 **같은 길**로 보낸다 — 한 장짜리 목록일 뿐이다. 따로 두면 카운트다운과
 * 마스크 캐시가 두 벌이 되고, 언젠가 한쪽만 고치게 된다.
 */
async function burstImage(src) {
  imageCount += 1
  await playItems({ gap: 1, items: [{ id: `한장:${imageCount}`, kind: 'image', dataUrl: src, on: true }] })
}

/**
 * 문구 한 발. 보관함의 문구 항목이 이 길로 간다.
 *
 * 색은 문구 글자로 정한다(`paletteFor`) — 쏠 때마다 색이 바뀌면 「그 문구」로 안 읽힌다.
 */
function textCue(text, delay) {
  const key = `문구:${text}`
  if (!textMasks[key]) {
    try {
      textMasks[key] = buildMask(text)
    } catch (error) {
      console.error(`문구 마스크 실패: ${text} — ${error}`)
      return null
    }
    syncMasks()
  }
  return {
    cue: {
      pad: 4,
      height: 0.58,
      x: 0.5,
      trail: '#ffffff',
      burst: {
        type: 'text',
        text: key,
        // 폭으로 맞춘다. 무슨 문구가 올지 모르는데 높이로 맞추면 긴 문구가 화면 밖으로 나간다.
        width: Math.min(0.75, 0.18 + text.length * 0.06),
        count: 700 + text.length * 260,
        size: 2.5,
        life: 4.4,
        colors: PALETTE[paletteFor(text)],
      },
    },
    delay,
  }
}

/** 이미지 한 발의 큐. 마스크는 미리 만들어 둔 것을 쓴다. */
function imageCue(key, delay) {
  return {
    cue: {
      pad: 4,
      height: 0.62,
      x: 0.5,
      trail: '#ffffff',
      burst: {
        type: 'text',
        mask: key,
        fit: IMAGE_FIT,
        count: IMAGE_COUNT,
        size: IMAGE_SIZE,
        hold: IMAGE_HOLD,
        twinkle: 0,
        // 꼬리를 안 끈다. 그림이 번지지 않게 하려는 것이기도 하고, 맥 웹뷰가 이 수의
        // 선분을 한 프레임에 못 그려서 화면이 통째로 멈추기 때문이기도 하다.
        streak: false,
        life: IMAGE_HOLD + 2.0,
        colors: ['#ffffff'],
      },
    },
    delay,
  }
}

/**
 * 한 프레임 양보한다. 마스크를 여러 장 만드는 동안 화면이 멈추지 않게 하려는 것이다.
 *
 * **`requestAnimationFrame` 만으로는 안 된다.** 창이 가려져 있거나 숨겨져 있으면
 * (⌥⇧H, 다른 창에 완전히 덮임, 브라우저의 배경 탭) rAF 가 아예 안 불려서 여기서 영영
 * 멈춘다 — 목록이 조용히 안 나간다. 그래서 시간 제한을 같이 건다.
 */
function yieldFrame() {
  return new Promise((resolve) => {
    let done = false
    const finish = () => {
      if (done) return
      done = true
      resolve()
    }
    requestAnimationFrame(finish)
    setTimeout(finish, 32)
  })
}

/**
 * 보관함이 보낸 목록을 쏜다.
 *
 * **마스크를 먼저 다 만들고 나서 순서를 건다.** 이미지 한 장을 마스크로 바꾸는 데 100ms
 * 가 걸려서, 쏘는 순간에 스무 장을 만들면 2 초가 멈춘다. 한 장 만들 때마다 프레임을
 * 양보해서 화면이 멈추지 않게 한다 — 프레임률이 잠깐 떨어질 뿐이다.
 *
 * 만든 마스크는 항목 id 로 캐시하므로 두 번째 재생부터는 곧바로 나간다.
 */
async function playItems(payload) {
  const list = Array.isArray(payload?.items) ? payload.items : []
  const gap = Math.max(0.5, Number(payload?.gap) || 5)
  if (list.length === 0) return

  // ① 마스크 만들기. 한 장에 한 번씩 양보한다.
  for (const item of list) {
    if (item.kind !== 'image' || imageMasks.has(item.id)) continue
    await yieldFrame()
    try {
      imageMasks.set(item.id, await buildImageMask(item.dataUrl))
    } catch (error) {
      console.error(`이미지를 못 읽었다: ${item.name ?? item.id} — ${error}`)
    }
    // 오래된 것부터 버린다. Map 은 넣은 순서를 지키므로 첫 키가 가장 오래된 것이다.
    while (imageMasks.size > IMAGE_KEEP) imageMasks.delete(imageMasks.keys().next().value)
  }

  // ② 카운트다운을 맨 앞에 한 번. 항목마다 세면 세는 것이 쇼가 된다.
  if (countdown > 0) ensureCountMasks(countdown)
  syncMasks()
  for (const step of planCountdown(countdown, COUNT_STEP)) {
    launchNow(world, {
      pad: 4, height: 0.62, x: 0.5, trail: '#ffd76a',
      burst: { type: 'text', text: String(step.n), ...COUNT_BURST },
    }, step.at)
  }

  // ③ 목록을 간격대로 건다. 카운트다운이 있으면 「1」에서 정확히 한 박자 뒤에 시작한다.
  const lead = countdownLead(countdown, COUNT_STEP)
  for (const slot of planPlaylist(list, gap, lead)) {
    const item = slot.item
    const planned = item.kind === 'text'
      ? textCue(item.text ?? '', slot.at)
      : (imageMasks.has(item.id) ? imageCue(item.id, slot.at) : null)
    if (planned) launchNow(world, planned.cue, planned.delay)
  }
  syncMasks()
  hintTime = HINT_SHOW + HINT_FADE // 목록을 쏘는 동안 안내가 가리지 않게
}

const audio = createAudio()

// ── 셸이 주는 다리. 브라우저로 열면 없고, 없어도 쇼는 그냥 돈다.
const bridge = window.sneaky
let hint = bridge?.keyHint ?? '⌥⇧F 다시 보기 · ⌥⇧H 숨기기'

// 셸이 기억해 둔 소리 크기가 있으면 그걸로 시작한다.
if (audio && typeof bridge?.volume === 'number') audio.setVolume(bridge.volume)
bridge?.onVolume?.((value) => audio?.setVolume(value))
bridge?.onRestart?.(() => {
  restartWorld(world)
  hintTime = 0
})
bridge?.onHint?.((text) => {
  hint = text
  hintTime = 0
})

// 셸이 기억해 둔 템플릿이 있으면 그걸로 시작한다.
if (typeof bridge?.template === 'string' && TEMPLATES[bridge.template]) applyTemplate(bridge.template)

bridge?.onTemplate?.((key) => applyTemplate(key))

// 셸이 기억해 둔 카운트다운.
if (typeof bridge?.countdown === 'number') countdown = Math.max(0, Math.round(bridge.countdown))
bridge?.onCountdown?.((value) => {
  countdown = Math.max(0, Math.round(value) || 0)
})

// 이미지가 왔다. 못 읽어도 쇼는 계속돼야 한다 — 그 한 발만 조용히 없던 일이 된다.
bridge?.onImage?.((src) => {
  burstImage(src).catch((error) => console.error(`이미지 불꽃 실패: ${error}`))
})

// 보관함이 보낸 목록. 셸이 두 웹뷰 사이를 이어 준다 — 웹뷰끼리는 직접 말할 수 없다.
bridge?.onPlay?.((payload) => {
  playItems(payload).catch((error) => console.error(`보관함 재생 실패: ${error}`))
})

// 셸에 템플릿 목록을 알려 준다. **목록의 주인은 여기(script.js)다** — 셸 두 개에 베껴
// 두면 템플릿을 하나 더할 때마다 세 군데를 고쳐야 하고, 언젠가 한 군데를 빠뜨린다.
bridge?.send?.({
  type: 'templates',
  items: Object.entries(TEMPLATES).map(([key, template]) => ({ key, name: template.name })),
  current: templateKey,
})

// 브라우저로 열어 볼 때를 위한 임시 조작. 셸에서는 핫키가 이 자리를 대신한다.
window.addEventListener('keydown', (event) => {
  if (event.key === 'r' || event.key === 'R') {
    restartWorld(world)
    hintTime = 0
  }
})

// 웹뷰가 소리를 막고 있으면 첫 상호작용에서 깨운다. 셸에서는 애초에 막지 않게 해 두었다.
window.addEventListener('pointerdown', () => audio?.resume(), { once: true })

let accumulator = 0
let last = performance.now() / 1000

function frame(now) {
  const seconds = now / 1000
  let elapsed = seconds - last
  last = seconds

  // 창이 가려졌다 돌아오면 elapsed 가 몇 초씩 된다. 그대로 넣으면 그 시간만큼 쇼를
  // 몰아서 돌리느라 한 프레임이 멈춘다 — 잘라 낸다.
  if (elapsed > 0.25) elapsed = 0.25

  accumulator += elapsed
  hintTime += elapsed

  while (accumulator >= DT) {
    stepWorld(world, DT)
    accumulator -= DT
  }

  if (audio) audio.play(drainSounds(world))
  else drainSounds(world)

  const hintAlpha = hintTime < HINT_SHOW
    ? 1
    : Math.max(0, 1 - (hintTime - HINT_SHOW) / HINT_FADE)
  draw(ctx, world, { hint, hintAlpha })

  requestAnimationFrame(frame)
}

window.addEventListener('resize', () => fit(world))
requestAnimationFrame(frame)

/**
 * 확인용 손잡이. 쇼의 어느 지점이 어떻게 보이는지 눈으로 볼 때 쓴다 —
 * 하트가 하트로 보이는지, 글자가 읽히는지는 테스트로 알 수 없고 봐야만 안다.
 * 브라우저 콘솔에서 `__fw.seek(34)` 처럼 부른다.
 */
window.__fw = {
  world,
  /** 이미지 불꽃을 눈으로 볼 때. data URL 도 되고 같은 폴더의 파일 이름도 된다. */
  image: (src) => burstImage(src),
  /** 카운트다운을 몇 초부터 셀지. 0 이면 안 센다. */
  countdown: (seconds) => { countdown = Math.max(0, Math.round(seconds) || 0) },
  /** 보관함이 보내는 것과 같은 모양으로 목록을 쏜다. */
  play: (payload) => playItems(payload),
  /** 템플릿을 바꿔 본다. `__fw.template('birthday')` */
  template: (key) => applyTemplate(key),
  templates: () => Object.keys(TEMPLATES),
  seek(seconds) {
    restartWorld(world)
    world.particles = []
    world.shells = []
    const count = Math.round(seconds / DT)
    for (let i = 0; i < count; i += 1) stepWorld(world, DT)
    drainSounds(world) // 몰아서 돌린 만큼의 소리가 한꺼번에 터지지 않게 버린다
  },
}
