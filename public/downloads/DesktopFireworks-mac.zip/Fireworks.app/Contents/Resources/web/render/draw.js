// 그리기. 월드를 캔버스에 옮기는 일만 한다 — 상태를 바꾸지 않는다.
//
// **배경을 칠하지 않는다.** 보통 불꽃놀이 캔버스는 매 프레임 검은 반투명을 덮어 잔상을
// 만들지만, 이 앱이 그러면 바탕화면이 가려져서 「투명 오버레이」가 아니게 된다. 그래서
// 매 프레임 통째로 지우고, 잔상은 파티클이 들고 다니는 지난 위치로 직접 그린다.
//
// 그리는 양이 곧 성능이라, 파티클 하나에 선 하나 + 점 하나만 쓴다. 그리고 **같은 색·
// 같은 밝기끼리 묶어 한 번에** 그린다 — 파티클마다 stroke() 를 부르면 3000 개에서
// 프레임이 무너진다.
//
// **선분과 점은 값이 다르다.** 맥 웹뷰에서 재 보니 점 18000 개는 4ms 인데 같은 수의
// 선분은 한 프레임에 10 초가 걸렸다(크롬에서는 11ms 라 안 보인다 — 오버레이는 투명
// 창이라 래스터라이즈가 다르게 돈다). 그래서 아래 세 가지로 선분 수를 줄인다:
// 색을 뭉쳐 묶음을 만들고, 길이 0 인 궤적은 안 긋고, 궤적이 없는 파티클은 점만 찍는다.

import { brightness } from '../show/particles.js'
import { TRAIL_LENGTH } from '../show/constants.js'
import { padGlow, PAD_HEIGHT } from '../show/launcher.js'

/** 밝기를 몇 단계로 뭉갤지. 많을수록 곱지만 묶음이 늘어난다. */
const ALPHA_STEPS = 12

/** 빛무리를 얼마나 굵고 옅게 얹을지. 가산 합성이라 겹칠수록 하얗게 타오른다. */
const GLOW_WIDTH = 3.4
const GLOW_ALPHA = 0.16

/** 굵기를 몇 단계로 뭉갤지. */
const WIDTH_STEPS = 4
const MAX_WIDTH = 4.5

/**
 * 색을 채널당 몇 비트 버릴지.
 *
 * 글자 불꽃은 팔레트에서 색을 뽑아 서너 가지뿐이라 묶음이 저절로 생긴다. 그런데
 * **이미지 불꽃은 점마다 그 픽셀의 색**이라, 뭉개지 않으면 묶음이 안 생긴다 — 하치와레
 * 한 장에서 점 17977 개의 색이 2544 가지였다. 4 비트를 버리면(채널당 16 단계) 155 가지가
 * 된다. 색 눈금 16 은 점묘화에서 눈에 안 띈다 — 밝기는 이미 12 단계로 뭉개고 있다.
 */
const RGB_BITS = 4
const RGB_LEVELS = 256 >> RGB_BITS

/** 이보다 짧은 궤적은 안 긋는다(제곱 거리). 서 있는 파티클의 길이 0 짜리 선분을 뺀다. */
const MIN_TRAIL2 = 1

/**
 * 묶음 키. **문자열이 아니라 정수다.** 파티클마다 문자열을 만들면 18000 개에서 그
 * 자체가 비용이 되고, Map 의 문자열 해시도 정수보다 느리다.
 */
function bucketKey(rgb, alphaLevel, widthLevel) {
  const color = ((rgb[0] >> RGB_BITS) * RGB_LEVELS + (rgb[1] >> RGB_BITS)) * RGB_LEVELS
    + (rgb[2] >> RGB_BITS)
  return (color * (ALPHA_STEPS + 1) + alphaLevel) * (WIDTH_STEPS + 1) + widthLevel
}

/**
 * 파티클 하나를 묶음에 넣는다. 선분은 궤적의 가장 오래된 점에서 지금 위치까지 하나만
 * 긋는다 — 6 점을 다 이어도 0.15 초치 탄도라 눈에 띄게 휘지 않는데, 그리는 비용은
 * 다섯 배가 된다.
 */
function collect(buckets, p, b) {
  const alphaLevel = Math.max(1, Math.round(b * ALPHA_STEPS))
  const width = Math.min(MAX_WIDTH, p.size * (0.5 + b))
  const widthLevel = Math.max(1, Math.round((width / MAX_WIDTH) * WIDTH_STEPS))
  const key = bucketKey(p.rgb, alphaLevel, widthLevel)

  let bucket = buckets.get(key)
  if (!bucket) {
    bucket = {
      rgb: p.rgb,
      alpha: alphaLevel / ALPHA_STEPS,
      width: (widthLevel / WIDTH_STEPS) * MAX_WIDTH,
      segs: [],
      dots: [],
    }
    buckets.set(key, bucket)
  }

  // 궤적을 안 그리는 파티클(이미지의 점)과 제자리에 선 파티클은 선분을 안 만든다.
  if (p.streak !== false) {
    const oldest = (p.head + 1) % TRAIL_LENGTH
    const ox = p.trail[oldest * 2]
    const oy = p.trail[oldest * 2 + 1]
    if ((ox - p.x) ** 2 + (oy - p.y) ** 2 > MIN_TRAIL2) bucket.segs.push(ox, oy, p.x, p.y)
  }
  bucket.dots.push(p.x, p.y)
}

function paint(ctx, buckets) {
  for (const bucket of buckets.values()) {
    const [r, g, b] = bucket.rgb

    // 그을 선분이 하나도 없으면 경로도 안 만들고 stroke 도 안 부른다.
    if (bucket.segs.length > 0) {
      ctx.beginPath()
      for (let i = 0; i < bucket.segs.length; i += 4) {
        ctx.moveTo(bucket.segs[i], bucket.segs[i + 1])
        ctx.lineTo(bucket.segs[i + 2], bucket.segs[i + 3])
      }

      // 빛무리 먼저, 그 위에 또렷한 선. 같은 경로를 굵기·투명도만 바꿔 두 번 칠하는
      // 것이라 경로를 다시 만들 필요가 없다 — shadowBlur 로 번지게 하는 것보다 훨씬 싸다.
      ctx.strokeStyle = `rgba(${r},${g},${b},${bucket.alpha * GLOW_ALPHA})`
      ctx.lineWidth = bucket.width * GLOW_WIDTH
      ctx.stroke()

      ctx.strokeStyle = `rgba(${r},${g},${b},${bucket.alpha})`
      ctx.lineWidth = bucket.width
      ctx.stroke()
    }

    // 머리의 점. 선만 있으면 불씨가 아니라 실오라기로 보인다.
    ctx.fillStyle = `rgba(${r},${g},${b},${bucket.alpha})`
    const radius = bucket.width * 0.62
    ctx.beginPath()
    for (let i = 0; i < bucket.dots.length; i += 2) {
      ctx.moveTo(bucket.dots[i] + radius, bucket.dots[i + 1])
      ctx.arc(bucket.dots[i], bucket.dots[i + 1], radius, 0, Math.PI * 2)
    }
    ctx.fill()
  }
}

/**
 * 발사대. 유일하게 가산 합성을 쓰지 않는 부분이다 — 가산으로 그리면 어두운 금속이
 * 바탕화면 위에서 사라진다.
 */
function drawPads(ctx, world) {
  ctx.globalCompositeOperation = 'source-over'
  for (const pad of world.pads) {
    const glow = padGlow(pad)

    ctx.save()
    ctx.translate(pad.x, pad.baseY)
    ctx.rotate(pad.tilt)

    // 관
    ctx.fillStyle = 'rgba(24,22,30,0.82)'
    ctx.fillRect(-5, -PAD_HEIGHT, 10, PAD_HEIGHT)
    ctx.fillStyle = 'rgba(120,118,135,0.5)'
    ctx.fillRect(-5, -PAD_HEIGHT, 2, PAD_HEIGHT)

    // 받침
    ctx.fillStyle = 'rgba(18,16,24,0.85)'
    ctx.beginPath()
    ctx.moveTo(-13, 0)
    ctx.lineTo(13, 0)
    ctx.lineTo(8, -8)
    ctx.lineTo(-8, -8)
    ctx.closePath()
    ctx.fill()

    ctx.restore()

    if (glow > 0) {
      // 섬광은 가산으로. 관 입구가 확 밝아지는 것이 발사의 신호다.
      ctx.globalCompositeOperation = 'lighter'
      const gradient = ctx.createRadialGradient(pad.x, pad.muzzleY, 0, pad.x, pad.muzzleY, 46 * glow)
      gradient.addColorStop(0, `rgba(255,226,160,${0.85 * glow})`)
      gradient.addColorStop(1, 'rgba(255,150,40,0)')
      ctx.fillStyle = gradient
      ctx.fillRect(pad.x - 50, pad.muzzleY - 50, 100, 100)
      ctx.globalCompositeOperation = 'source-over'
    }
  }
}

/**
 * 한 프레임.
 * @param {CanvasRenderingContext2D} ctx
 * @param {object} world
 * @param {{hintAlpha?: number, hint?: string}} [options] 처음 몇 초만 띄우는 안내
 */
export function draw(ctx, world, options = {}) {
  // **변환을 건드리지 않는다.** 렌더러가 fit() 에서 레티나 배율(dpr)을 한 번 걸어 두었고,
  // 여기서 항등으로 되돌리면 그 배율이 지워져 화면 왼쪽 위 1/4 에만 그려진다.
  // 테스트는 전부 초록인데 눈으로만 보이던 버그였다 — 실제로 띄워 보고서야 찾았다.
  ctx.clearRect(0, 0, world.width, world.height)

  drawPads(ctx, world)

  ctx.globalCompositeOperation = 'lighter'
  ctx.lineCap = 'round'

  const buckets = new Map()
  for (const shell of world.shells) {
    const b = brightness(shell.p)
    if (b > 0.02) collect(buckets, shell.p, b)
  }
  for (const p of world.particles) {
    const b = brightness(p)
    if (b > 0.02) collect(buckets, p, b)
  }
  paint(ctx, buckets)

  ctx.globalCompositeOperation = 'source-over'

  if (options.hint && options.hintAlpha > 0.01) {
    ctx.font = '13px -apple-system, "Segoe UI", "Apple SD Gothic Neo", "Malgun Gothic", sans-serif'
    ctx.textBaseline = 'bottom'
    // 밝은 바탕화면에서도 읽히도록 어두운 테두리를 먼저 깐다.
    ctx.strokeStyle = `rgba(0,0,0,${0.55 * options.hintAlpha})`
    ctx.lineWidth = 3
    ctx.strokeText(options.hint, 18, world.height - PAD_HEIGHT - 14)
    ctx.fillStyle = `rgba(255,255,255,${0.8 * options.hintAlpha})`
    ctx.fillText(options.hint, 18, world.height - PAD_HEIGHT - 14)
  }
}
