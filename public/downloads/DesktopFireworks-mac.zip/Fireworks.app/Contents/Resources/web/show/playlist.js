// 보관함이 「고른 것 차례로 쏘기」를 눌렀을 때 무엇을 언제 쏠지 푸는 곳.
//
// 순수 함수다. `window` 도 시계도 모른다 — 몇 초 뒤에 무엇을 쏠지 적은 표를 돌려줄 뿐이고,
// 실제로 거는 것은 렌더러가 엔진의 예약 발사에 넘긴다. 그래야 테스트가 돈다.

/** 문구 색으로 쓸 팔레트 이름. script.js 의 PALETTE 와 같은 이름이어야 한다. */
export const TEXT_PALETTES = ['rose', 'gold', 'ice', 'mint', 'violet', 'white']

/**
 * 문구에 붙일 팔레트를 고른다.
 *
 * **글자에서 정한다.** 난수로 고르면 같은 문구가 쏠 때마다 다른 색으로 나와서 「그 문구」로
 * 안 읽힌다. 글자를 훑어 만든 값으로 고르면 같은 문구는 언제나 같은 색이다.
 */
export function paletteFor(text) {
  let hash = 0
  for (let i = 0; i < text.length; i += 1) {
    // 자리마다 다른 무게를 줘야 글자 순서가 바뀌면 색도 바뀐다.
    //
    // 흔히 쓰는 31 은 여기서 못 쓴다. 팔레트가 여섯 개이고 **31 을 6 으로 나눈 나머지가
    // 1** 이라, 나머지만 보면 자리 무게가 통째로 사라진다 — 「AB」와 「BA」가 같은 색이
    // 된다. 131 은 6 으로 나눈 나머지가 5 라 그런 일이 없다.
    hash = (hash * 131 + text.charCodeAt(i)) % 1000003
  }
  return TEXT_PALETTES[hash % TEXT_PALETTES.length]
}

/**
 * 목록을 「몇 초 뒤에 무엇을」 로 편다.
 *
 * - 꺼 둔 항목(`on !== true`)은 건너뛴다. 건너뛴 자리만큼 뒤가 당겨진다 — 꺼 둔 항목이
 *   빈 시간으로 남으면 목록 가운데를 끄는 순간 쇼에 구멍이 생긴다.
 * - `lead` 는 맨 앞에 비워 두는 시간이다. 카운트다운이 그 자리를 쓴다.
 *
 * @param {{id: string, on?: boolean}[]} items 보관함 순서 그대로
 * @param {number} gap 항목 사이 간격(초)
 * @param {number} lead 첫 항목까지 비워 둘 시간(초)
 * @returns {{item: object, at: number}[]} 시간순
 */
export function planPlaylist(items, gap, lead = 0) {
  const out = []
  for (const item of items) {
    if (item.on !== true) continue
    out.push({ item, at: lead + out.length * gap })
  }
  return out
}

/**
 * 카운트다운 숫자를 언제 쏠지.
 *
 * 마지막 숫자(1)가 뜬 **다음** 순간에 첫 항목이 와야 한다. 그래서 첫 항목의 `lead` 는
 * `seconds * step` 이고, 숫자 n 은 `(seconds - n) * step` 에 나간다.
 *
 * @returns {{n: number, at: number}[]} 큰 수부터
 */
export function planCountdown(seconds, step = 1) {
  const out = []
  for (let n = Math.round(seconds); n >= 1; n -= 1) {
    out.push({ n, at: (Math.round(seconds) - n) * step })
  }
  return out
}

/**
 * 카운트다운이 끝나고 첫 항목이 나갈 시각.
 *
 * **`planCountdown` 이 실제로 잡은 마지막 숫자에서 센다.** 이걸 손으로 `seconds * step`
 * 이라고 다시 적었다가 한 박자를 더 세는 실수를 이미 한 번 했다 — 숫자 셋은 3 초가 아니라
 * 2 초를 차지한다(3 이 0 초, 2 가 1 초, 1 이 2 초). 거기에 여유까지 더해서 「1」과 이미지
 * 사이가 1.8 초 비었고, 세는 것이 끝난 줄 알았는데 아무 일도 안 일어났다.
 *
 * 그래서 「1」에서 **정확히 한 박자 뒤**다. 세던 박자를 그대로 이어받아 터지는 것이
 * 카운트다운이다.
 */
export function countdownLead(seconds, step = 1) {
  const steps = planCountdown(seconds, step)
  if (steps.length === 0) return 0
  return steps[steps.length - 1].at + step
}
