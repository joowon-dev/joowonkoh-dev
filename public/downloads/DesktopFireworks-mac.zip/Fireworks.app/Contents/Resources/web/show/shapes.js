// 터짐의 모양. 전부 순수 함수다.
//
// 모든 함수는 **화면 좌표계**(y 가 아래쪽)의 벡터 배열을 준다. 크기는 대체로 1 이하로
// 맞춰 두었고, 엔진이 여기에 속도(방향 방식)나 반지름(목표 방식)을 곱한다.
//
// `speed` 는 방향마다 다른 세기다. 국화처럼 안쪽까지 채우는 불꽃은 이 값이 0~1 로
// 흩어지고, 고리처럼 테두리만 있는 불꽃은 전부 1 에 가깝다.

import { range } from './rng.js'

/**
 * @typedef {{ x: number, y: number, speed: number }} Direction
 */

/**
 * 국화 — 가장 흔한 둥근 불꽃. 3차원 구면에 고르게 뿌린 뒤 화면에 그대로 눌러 담는다.
 * 평면에서 각도만 고르게 뽑으면 가운데가 비어 보이는데, 구면을 눌러 담으면 테두리가
 * 진하고 가운데가 옅은 실제 불꽃의 밀도가 그냥 나온다.
 */
export function peonyDirections(count, rng) {
  const out = []
  for (let i = 0; i < count; i += 1) {
    // 구면 위 균등 분포: z 를 [-1,1] 균등하게 뽑는다.
    const z = range(rng, -1, 1)
    const r = Math.sqrt(1 - z * z)
    const a = range(rng, 0, Math.PI * 2)
    out.push({ x: r * Math.cos(a), y: r * Math.sin(a), speed: range(rng, 0.75, 1) })
  }
  return out
}

/** 고리 — 테두리만. 살짝 흔들어야 자로 그린 원처럼 안 보인다. */
export function ringDirections(count, rng) {
  const out = []
  for (let i = 0; i < count; i += 1) {
    const a = (i / count) * Math.PI * 2 + range(rng, -0.02, 0.02)
    out.push({ x: Math.cos(a), y: Math.sin(a), speed: range(rng, 0.94, 1) })
  }
  return out
}

/**
 * 하트. 고전적인 매개변수 곡선을 쓴다.
 *   x = 16 sin³t,  y = 13 cos t − 5 cos 2t − 2 cos 3t − cos 4t
 * 이 곡선은 원점이 가운데가 아니다 — y 가 −17 … +11.92 라 가운데가 −2.538 이다.
 * 그만큼 밀어 올려야 하트가 화면에서 위아래로 치우치지 않는다.
 * 화면 좌표라 y 를 뒤집는다 — 뒤집지 않으면 뾰족한 끝이 위로 간다.
 */
export function heartDirections(count, rng) {
  const out = []
  const shift = 2.538 // 곡선 y 범위의 가운데. 이만큼 더해야 0 이 하트의 중심이 된다
  const scale = 1 / 16
  for (let i = 0; i < count; i += 1) {
    const t = (i / count) * Math.PI * 2
    const mx = 16 * Math.sin(t) ** 3
    const my = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)
    // 테두리에서 살짝 안쪽으로도 흩뿌려 속을 채운다. 완전히 빈 하트는 멀리서 안 읽힌다.
    const fill = range(rng, 0.82, 1)
    out.push({
      x: mx * scale * fill,
      y: -(my + shift) * scale * fill,
      speed: range(rng, 0.95, 1),
    })
  }
  return out
}

/** 별 — 꼭짓점 5 개의 별 모양 테두리. */
export function starDirections(count, rng, points = 5) {
  const out = []
  const inner = 0.42
  for (let i = 0; i < count; i += 1) {
    const t = (i / count) * points // 0..points, 한 칸이 꼭짓점 하나
    const seg = Math.floor(t)
    const f = t - seg
    // 꼭짓점 → 안쪽 → 다음 꼭짓점으로 직선으로 간다.
    const a0 = (seg / points) * Math.PI * 2 - Math.PI / 2
    const a1 = ((seg + 0.5) / points) * Math.PI * 2 - Math.PI / 2
    const a2 = ((seg + 1) / points) * Math.PI * 2 - Math.PI / 2
    const p0 = [Math.cos(a0), Math.sin(a0)]
    const p1 = [Math.cos(a1) * inner, Math.sin(a1) * inner]
    const p2 = [Math.cos(a2), Math.sin(a2)]
    const [ax, ay] = f < 0.5 ? p0 : p1
    const [bx, by] = f < 0.5 ? p1 : p2
    const g = f < 0.5 ? f * 2 : (f - 0.5) * 2
    const fill = range(rng, 0.86, 1)
    out.push({ x: (ax + (bx - ax) * g) * fill, y: (ay + (by - ay) * g) * fill, speed: 1 })
  }
  return out
}

/**
 * 수양버들 — 위로 퍼졌다가 길게 늘어져 떨어지는 불꽃. 방향을 위쪽으로 치우치게 주고,
 * 엔진이 이 종류에 긴 수명과 약한 항력을 준다. 늘어지는 모양은 중력이 만든다.
 */
export function willowDirections(count, rng) {
  const out = []
  for (let i = 0; i < count; i += 1) {
    const a = range(rng, 0, Math.PI * 2)
    const up = range(rng, 0.15, 1)
    out.push({ x: Math.cos(a) * up, y: Math.sin(a) * up * 0.55 - 0.35, speed: range(rng, 0.6, 1) })
  }
  return out
}

/** 모양 이름 → 방향 함수. 각본이 문자열로 부르므로 여기 없는 이름은 국화로 떨어진다. */
const BY_NAME = {
  peony: peonyDirections,
  ring: ringDirections,
  heart: heartDirections,
  star: starDirections,
  willow: willowDirections,
}

/**
 * 각본이 준 모양 이름으로 방향을 만든다.
 * @returns {Direction[]}
 */
export function directionsFor(type, count, rng) {
  return (BY_NAME[type] ?? peonyDirections)(count, rng)
}

/**
 * 글자 마스크에서 목표점을 뽑는다.
 *
 * 마스크는 렌더러가 오프스크린 캔버스에 문구를 그려서 만든다 — 캔버스가 필요한 일이라
 * 여기(순수 모듈)에서는 하지 않고, 이미 만들어진 알파 배열만 받는다. 그래서 이 함수는
 * 테스트가 돌고, 한글이든 이모지든 폰트가 그릴 수 있으면 그대로 된다.
 *
 * 좌표는 **가로 절반을 1 로 놓고** 정규화한다(가로세로 비율 유지). 그래서 엔진은
 * 「글자를 화면 폭의 몇 %로 세울지」만 정하면 된다.
 *
 * 마스크에 `rgb`(픽셀당 세 칸)가 있으면 점마다 **그 점의 픽셀 색**을 같이 돌려준다.
 * 이미지 불꽃이 원본 색으로 터지는 근거가 이것이다. 없으면 색을 붙이지 않는다 —
 * 글자 마스크에는 `rgb` 가 없으므로 글자는 지금까지와 똑같이 팔레트로 터진다.
 *
 * @param {{data: ArrayLike<number>, width: number, height: number,
 *          rgb?: ArrayLike<number>}} mask 알파 0~255, rgb 는 픽셀당 R·G·B 세 칸
 * @param {number} count 뽑을 점의 수
 * @param {() => number} rng
 * @param {number} threshold 이보다 진한 픽셀만 글자로 본다
 * @returns {{x: number, y: number, rgb?: number[]}[]} 빈 마스크면 빈 배열
 */
export function sampleMask(mask, count, rng, threshold = 128) {
  const { data, width, height, rgb } = mask
  const lit = []
  for (let i = 0; i < width * height; i += 1) {
    if (data[i] >= threshold) lit.push(i)
  }
  if (lit.length === 0 || count <= 0) return []

  const halfW = width / 2
  const halfH = height / 2
  const out = []
  // 고르게 훑는다 — 난수로 뽑으면 같은 픽셀이 겹쳐 글자에 구멍이 난다.
  for (let i = 0; i < count; i += 1) {
    const index = lit[Math.floor((i / count) * lit.length)]
    const px = index % width
    const py = Math.floor(index / width)
    // 픽셀 안에서 조금 흔들어야 격자 무늬가 안 보인다.
    const point = {
      x: (px + range(rng, 0, 1) - halfW) / halfW,
      y: (py + range(rng, 0, 1) - halfH) / halfW,
    }
    // 색은 반드시 **그 점의 픽셀**에서 가져온다. 마스크 하나에 색 하나를 붙이면
    // 이미지가 아니라 단색 실루엣이 된다.
    if (rgb) point.rgb = [rgb[index * 3], rgb[index * 3 + 1], rgb[index * 3 + 2]]
    out.push(point)
  }
  return out
}

/**
 * 마스크에서 실제로 칠해진 만큼만 남긴다.
 *
 * 캔버스가 필요 없는 순수한 일이라 여기(순수 모듈)에 둔다 — 렌더러에 두면 색이 알파와
 * 같은 자리로 잘리는지를 테스트가 볼 수 없다.
 *
 * 자르지 않으면 마스크의 크기가 글자가 아니라 **캔버스의 여백**에 좌우된다 — 「I」처럼
 * 좁은 글자는 여백이 대부분이라, 크기를 어떻게 주든 엉뚱한 비율로 선다. 잘라 두면
 * 마스크의 가로세로가 곧 글자의 가로세로가 되어, 엔진이 「이 높이로 세워라」를 지킬 수 있다.
 *
 * 마스크가 색(`rgb`)을 들고 있으면 **알파와 똑같은 자리로** 같이 자른다. 한쪽만 자르면
 * 색이 통째로 어긋나서, 이미지가 제 색이 아닌 색으로 터진다.
 */
export function cropMask(mask, threshold = 128) {
  const { data, width, height, rgb } = mask
  let minX = width, minY = height, maxX = -1, maxY = -1
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      if (data[y * width + x] < threshold) continue
      if (x < minX) minX = x
      if (x > maxX) maxX = x
      if (y < minY) minY = y
      if (y > maxY) maxY = y
    }
  }
  // 빈 마스크(공백만 있는 문구 등)는 그대로 돌려준다 — 엔진이 알아서 건너뛴다.
  if (maxX < 0) return mask

  const w = maxX - minX + 1
  const h = maxY - minY + 1
  const out = new Uint8Array(w * h)
  const outRgb = rgb ? new Uint8Array(w * h * 3) : null
  for (let y = 0; y < h; y += 1) {
    for (let x = 0; x < w; x += 1) {
      const from = (y + minY) * width + x + minX
      const to = y * w + x
      out[to] = data[from]
      if (outRgb) {
        outRgb[to * 3] = rgb[from * 3]
        outRgb[to * 3 + 1] = rgb[from * 3 + 1]
        outRgb[to * 3 + 2] = rgb[from * 3 + 2]
      }
    }
  }
  return outRgb
    ? { data: out, width: w, height: h, rgb: outRgb }
    : { data: out, width: w, height: h }
}

/**
 * 이미지 색의 어두운 쪽을 들어 올린다.
 *
 * 불꽃은 바탕화면 위에 **가산 합성**으로 그려진다 — 배경을 칠하지 않기 때문이다.
 * 그래서 어두운 픽셀은 「어둡게」 보이는 게 아니라 **아예 안 보인다.** 원본 색을 곧이곧대로
 * 쓰면 어두운 로고나 밤 사진은 올려도 화면에 아무것도 안 뜬다.
 *
 * 감마 곡선(`v ↦ 255·(v/255)^(1/2.2)`)을 쓴다. 이 곡선은
 *
 * - 흰색(255)을 흰색 그대로 두고,
 * - 채널 사이의 크기 순서를 지켜 **색조를 안 바꾸며**,
 * - 어두운 쪽만 크게 들어 올린다 (8 → 53, 64 → 136, 128 → 186).
 *
 * **이미 밝은 이미지에는 걸지 않는다.** 이 곡선은 어두운 쪽을 들어 올리는 대신 밝은 쪽을
 * 눌러 붙인다 — 224 는 240 이 되고 255 는 그대로라, 원래 12% 이던 차이가 6% 로 준다.
 * 밝은 배경 위의 밝은 그림(흰 캐릭터가 베이지 위에 있는 것 같은)은 그 차이가 전부인데,
 * 그걸 절반으로 깎으면 형체가 통째로 뭉개진다. 어두워서 안 보이는 이미지를 구하려던 것이
 * 밝은 이미지를 망치면 안 된다.
 *
 * 밝은지 어두운지는 **켜진 픽셀의 밝기 중앙값**으로 본다. 평균은 아주 밝은 몇 점에
 * 끌려가고, 최댓값은 흰 점 하나에 끌려간다.
 *
 * 밝기를 재서 배율을 정하는 방법(자동 게인)은 쓰지 않는다. 같은 이미지가 다른 이미지와
 * 섞이는 정도에 따라 달라 보이면 안 된다 — 여기서 재는 것은 그 이미지 하나뿐이라,
 * 같은 이미지는 언제나 같게 나온다.
 *
 * @param {number} bright 밝기 중앙값이 이보다 크면 손대지 않는다
 */
export function liftMask(mask, gamma = 1 / 2.2, bright = 128) {
  if (!mask.rgb) return mask
  if (medianLuminance(mask) > bright) return mask
  const rgb = new Uint8Array(mask.rgb.length)
  for (let i = 0; i < rgb.length; i += 1) {
    rgb[i] = Math.round(255 * (mask.rgb[i] / 255) ** gamma)
  }
  return { ...mask, rgb }
}

/** 켜진 픽셀의 밝기 중앙값. 꺼진 자리는 색이 아무 뜻도 없어서 안 센다. */
function medianLuminance(mask, threshold = 128) {
  const { data, rgb } = mask
  const hist = new Uint32Array(256)
  let lit = 0
  for (let i = 0; i < data.length; i += 1) {
    if (data[i] < threshold) continue
    const l = Math.round(0.299 * rgb[i * 3] + 0.587 * rgb[i * 3 + 1] + 0.114 * rgb[i * 3 + 2])
    hist[l] += 1
    lit += 1
  }
  if (lit === 0) return 0
  let seen = 0
  for (let v = 0; v < 256; v += 1) {
    seen += hist[v]
    if (seen * 2 >= lit) return v
  }
  return 255
}

/**
 * 단색 배경을 지운다.
 *
 * **왜 필요한가.** 투명도 없는 그림(로고·캐릭터 아트·PNG 로 저장한 일러스트)은 배경까지
 * 통째로 켜져서 화면에 **네모난 빛덩어리**가 뜬다. 가산 합성이라 밝은 배경은 주인공만큼
 * 밝게 타올라서, 그림이 배경에 묻힌다. 배경만 빼면 남는 것이 곧 실루엣이 되고, 검은
 * 눈·코·윤곽선은 「빛이 없는 자리」로 남아 오히려 이목구비가 된다.
 *
 * **어떻게.** 테두리에서 가장 흔한 색을 배경으로 보고, 테두리에서 시작해 **이어져 있으면서
 * 그 색과 비슷한** 픽셀만 따라 번져 가며 지운다. 이어진 것만 지우므로 그림 **안쪽**에 있는
 * 같은 색 부분(개 몸통 위의 베이지 무늬 같은 것)은 살아남는다.
 *
 * **안 도와줄 때는 가만히 있는다.**
 * - 이미 투명한 자리가 있으면 만든 사람이 배경을 정해 준 것이다 — 손대지 않는다.
 * - 테두리가 제각각인 사진은 거의 안 지워진다. 망가지는 게 아니라 그냥 그대로다.
 * - 화면을 거의 다 지우게 되면(온통 한 색) 아무것도 안 남으므로 되돌린다.
 *
 * @param {number} tolerance 배경 색과 이만큼(채널 거리) 안이면 배경으로 본다
 */
export function removeFlatBackground(mask, tolerance = 60) {
  const { data, width, height, rgb } = mask
  if (!rgb || width < 3 || height < 3) return mask

  // 이미 투명한 자리가 있으면 배경은 이미 정해져 있다.
  for (let i = 0; i < data.length; i += 1) if (data[i] < 250) return mask

  const reference = borderColor(rgb, width, height)
  const limit = tolerance * tolerance
  const near = (i) => {
    const dr = rgb[i * 3] - reference[0]
    const dg = rgb[i * 3 + 1] - reference[1]
    const db = rgb[i * 3 + 2] - reference[2]
    return dr * dr + dg * dg + db * db <= limit
  }

  // 테두리에서 시작하는 너비 우선 채우기. 이어진 것만 지우는 근거가 이 부분이다.
  const gone = new Uint8Array(width * height)
  const stack = []
  const push = (i) => {
    if (gone[i] || !near(i)) return
    gone[i] = 1
    stack.push(i)
  }
  for (let x = 0; x < width; x += 1) {
    push(x)
    push((height - 1) * width + x)
  }
  for (let y = 0; y < height; y += 1) {
    push(y * width)
    push(y * width + width - 1)
  }
  let removed = stack.length
  while (stack.length > 0) {
    const i = stack.pop()
    const x = i % width
    const y = (i - x) / width
    const before = stack.length
    if (x > 0) push(i - 1)
    if (x < width - 1) push(i + 1)
    if (y > 0) push(i - width)
    if (y < height - 1) push(i + width)
    removed += stack.length - before
  }

  // 온통 한 색이라 다 지워지면 아무것도 안 남는다. 그럴 바에는 그대로 두는 게 낫다.
  if (removed > data.length * 0.97) return mask

  const out = new Uint8Array(data.length)
  for (let i = 0; i < data.length; i += 1) out[i] = gone[i] ? 0 : data[i]
  return { ...mask, data: out }
}

/** 테두리 픽셀에서 가장 흔한 색. 한 픽셀만 집으면 모서리의 잡티에 끌려간다. */
function borderColor(rgb, width, height) {
  const counts = new Map()
  const add = (i) => {
    // 32 단위로 뭉쳐 세어야 자글자글한 그러데이션도 한 덩어리로 잡힌다.
    const key = `${rgb[i * 3] >> 5},${rgb[i * 3 + 1] >> 5},${rgb[i * 3 + 2] >> 5}`
    const bucket = counts.get(key) ?? { n: 0, r: 0, g: 0, b: 0 }
    bucket.n += 1
    bucket.r += rgb[i * 3]
    bucket.g += rgb[i * 3 + 1]
    bucket.b += rgb[i * 3 + 2]
    counts.set(key, bucket)
  }
  for (let x = 0; x < width; x += 1) {
    add(x)
    add((height - 1) * width + x)
  }
  for (let y = 0; y < height; y += 1) {
    add(y * width)
    add(y * width + width - 1)
  }
  let best = { n: 0, r: 0, g: 0, b: 0 }
  for (const bucket of counts.values()) if (bucket.n > best.n) best = bucket
  return [best.r / best.n, best.g / best.n, best.b / best.n]
}

/**
 * 이미지 마스크에서 목표점을 **정사각 격자로** 뽑는다.
 *
 * `sampleMask()` 는 켜진 픽셀을 목록으로 늘어놓고 일정 간격으로 건너뛴다. 글자에는
 * 문제없지만 **그림에는 못 쓴다** — 목록이 가로 줄 단위라, 건너뛰는 간격이 가로에만
 * 먹고 세로에는 안 먹는다. 60×40 을 600 점으로 뽑으면 가로 4 픽셀마다·세로 1 픽셀마다가
 * 되어, 그림이 가로로 눌리고 간격이 가로폭과 안 맞아떨어지는 만큼 **대각선 간섭무늬**가
 * 깔린다. 형체가 그 무늬에 갈려 없어진다.
 *
 * 여기서는 가로세로 같은 간격의 격자를 놓고 그 자리의 픽셀을 집는다. 간격은 켜진 넓이를
 * 점 수로 나눠 정하므로, 그림이 마스크의 몇 %를 차지하든 점이 그림에 고르게 깔린다.
 *
 * 격자에 흔들림을 조금 준다. 안 주면 화면에 격자 줄이 그대로 보인다 — 다만 흔들림이
 * 크면 다시 뭉개지므로 간격의 25% 까지만 준다.
 *
 * **미리 뽑아 두었으면 그걸 쓴다.** 512×512 마스크에서 18000 점을 뽑는 데 40ms 가 걸려서,
 * 터지는 순간에 하면 네 프레임이 멈춘다. 좌표를 화면 크기와 무관하게(가로 절반을 1 로)
 * 정규화해 두었기 때문에 **올릴 때 한 번 뽑아 두고 계속 쓸 수 있다** — 마스크에
 * `points` 가 있으면 그걸 그대로 돌려준다.
 *
 * @returns {{x: number, y: number, rgb?: number[]}[]}
 */
export function sampleImageMask(mask, count, rng, threshold = 128) {
  if (mask.points) return mask.points
  const { data, width, height, rgb } = mask
  if (count <= 0) return []

  let litCount = 0
  for (let i = 0; i < width * height; i += 1) if (data[i] >= threshold) litCount += 1
  if (litCount === 0) return []

  // 켜진 넓이를 점 수로 나눈 것이 격자 간격이다. 이렇게 해야 그림이 마스크의 몇 %를
  // 차지하든 점이 그림 위에 고르게 깔린다.
  const step = Math.max(1, Math.sqrt(litCount / count))
  const jitter = step * 0.25
  const halfW = width / 2
  const halfH = height / 2

  const out = []
  for (let gy = step / 2; gy < height; gy += step) {
    for (let gx = step / 2; gx < width; gx += step) {
      const px = Math.min(width - 1, Math.max(0, Math.round(gx)))
      const py = Math.min(height - 1, Math.max(0, Math.round(gy)))
      const index = py * width + px
      if (data[index] < threshold) continue

      const point = {
        x: (gx + range(rng, -jitter, jitter) - halfW) / halfW,
        y: (gy + range(rng, -jitter, jitter) - halfH) / halfW,
      }
      if (rgb) point.rgb = [rgb[index * 3], rgb[index * 3 + 1], rgb[index * 3 + 2]]
      out.push(point)
    }
  }
  return out
}
