// 탈것 칸. 모르는 탈것(옛 버전이 받은 새 탈것)은 화살로 대신 그린다.
import * as arrow from './arrow.js'

const CARRIERS = { arrow }

export const carrier = (kind) => CARRIERS[kind] ?? arrow
