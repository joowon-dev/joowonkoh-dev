// 사람이 손으로 넣는 코드 둘. 서버와 같은 글자판(0 O 1 I L 없음)을 쓴다.
export const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'
const ok = (text) => [...text].every((ch) => ALPHABET.includes(ch))
const squash = (text) => String(text ?? '').toUpperCase().replace(/[^A-Z0-9]/g, '')

/** 'cupid 7k2q9x' · '7K2Q9X' → 'CUPID-7K2Q9X'. 틀리면 null. */
export function normalizeCode(text) {
  let body = squash(text)
  if (body.startsWith('CUPID')) body = body.slice(5)
  return body.length === 6 && ok(body) ? `CUPID-${body}` : null
}

/** 복구 코드 16자 → 'XXXX-XXXX-XXXX-XXXX'. 틀리면 null. */
export function normalizeSecret(text) {
  const body = squash(text)
  if (body.length !== 16 || !ok(body)) return null
  return body.match(/.{4}/g).join('-')
}
