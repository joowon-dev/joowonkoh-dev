// 받은 화살 — 화면에 꽂힌 것과 화살통에 든 것. 먼저 온 LIMIT 개가 화면에 있다.
// 처음 가져오기와 실시간 알림이 겹쳐 같은 쪽지가 두 번 와도 하나로 친다.

export const LIMIT = 20

export function createInbox(limit = LIMIT) {
  const order = [] // 온 차례
  const byId = new Map()

  return {
    /** 'new'(화면에 꽂힌다) · 'quiver'(화살통으로) · 'dup'(이미 있다) */
    add(note) {
      if (byId.has(note.id)) return 'dup'
      byId.set(note.id, note)
      order.push(note.id)
      return order.length <= limit ? 'new' : 'quiver'
    },
    /** 뽑는다. 화살통에서 화면으로 올라온 쪽지가 있으면 그것을 돌려준다(없으면 null). */
    remove(id) {
      const at = order.indexOf(id)
      if (at < 0) return null
      order.splice(at, 1)
      byId.delete(id)
      return at < limit && order.length >= limit ? byId.get(order[limit - 1]) : null
    },
    has: (id) => byId.has(id),
    get: (id) => byId.get(id) ?? null,
    visible: () => order.slice(0, limit).map((id) => byId.get(id)),
    overflow: () => Math.max(0, order.length - limit),
  }
}
