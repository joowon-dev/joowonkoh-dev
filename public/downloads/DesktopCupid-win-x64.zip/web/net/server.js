// 진짜 서버(Supabase). 표는 잠겨 있고 모든 일은 RPC 다 — supabase/migrations/001_init.sql.
// 받기는 inbox 토큰 채널의 브로드캐스트로 「쪽지 id 만」 온다. 받으면 note(id) 로 가져온다.
import { CupidError } from './errors.js'

export function createServer({ supabaseUrl, supabaseKey }) {
  const sb = window.supabase.createClient(supabaseUrl, supabaseKey, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  })
  let secret = null
  let channel = null

  async function rpc(fn, args = {}, withSecret = true) {
    let result
    try {
      result = await sb.rpc(fn, withSecret ? { secret, ...args } : args)
    } catch {
      throw new CupidError('offline')
    }
    if (result.error) throw new CupidError(result.error.message)
    return result.data
  }

  return {
    kind: 'server',
    useSecret: (s) => { secret = s },
    async register(name) {
      const me = await rpc('cupid_register', { name }, false)
      secret = me.secret
      return me
    },
    me: () => rpc('cupid_me'),
    rename: (name) => rpc('cupid_rename', { name }),
    newCode: () => rpc('cupid_new_code'),
    async newSecret() {
      const me = await rpc('cupid_new_secret')
      secret = me.secret
      return me
    },
    deleteAccount: () => rpc('cupid_delete_account'),
    friends: () => rpc('cupid_friends'),
    addFriend: (code) => rpc('cupid_add_friend', { code }),
    removeFriend: (friend) => rpc('cupid_remove_friend', { friend }),
    send: (recipient, body, launch, carrier = 'arrow') => rpc('cupid_send', { recipient, body, carrier, launch }),
    unread: () => rpc('cupid_unread'),
    note: (id) => rpc('cupid_note', { id }),
    history: (friend) => rpc('cupid_history', { friend }),
    open: (id) => rpc('cupid_open', { id }),

    /** 내 inbox 채널을 듣는다. 이어질 때마다 onLive 가 불린다 — 그때 안 읽은 것을 다시 물어 끊긴 사이를 메운다. */
    listen(inbox, { onNote, onOpened, onLive, onDown }) {
      if (channel) sb.removeChannel(channel)
      channel = sb.channel(`inbox:${inbox}`)
      channel
        .on('broadcast', { event: 'note' }, (m) => onNote(m.payload.id))
        .on('broadcast', { event: 'opened' }, (m) => onOpened(m.payload.id))
        .subscribe((status) => {
          if (status === 'SUBSCRIBED') onLive()
          else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') onDown(status)
        })
    },
    stop() {
      if (channel) sb.removeChannel(channel)
      channel = null
    },
  }
}
