// 서버가 내는 오류 → 사람이 읽을 말.
export const MESSAGES = {
  bad_secret: '복구 코드가 맞지 않아요',
  bad_name: '이름은 1~20자로 해 주세요',
  bad_body: '쪽지는 1~200자로 써 주세요',
  not_friends: '친구가 아니라서 쏠 수 없어요',
  carrier_not_owned: '아직 없는 탈것이에요',
  too_many_notes: '한 시간에 60발까지예요. 조금 쉬었다 쏴요',
  too_many_tries: '코드를 너무 많이 넣었어요. 한 시간 뒤에 다시 해 주세요',
  no_such_code: '그런 코드가 없어요',
  own_code: '내 코드예요 — 친구 코드를 넣어 주세요',
  offline: '인터넷이 안 돼요',
}

export class CupidError extends Error {
  constructor(code) {
    super(MESSAGES[code] ?? code)
    this.code = MESSAGES[code] ? code : 'offline'
  }
}
