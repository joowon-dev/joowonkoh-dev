// 브라우저에서 돌릴 때(그리고 받는 곳 페이지의 데모)의 가짜 서버. 친구는 「메아리」 하나 —
// 메아리에게 쏜 화살은 1.2초 뒤 내 화면으로 되돌아와 꽂힌다.
import { CupidError } from './errors.js'

const ECHO = { id: 'echo', name: '메아리 (나에게 되돌아와요)' }

export function createFake() {
  let me = null
  let seq = 0
  const notes = []
  let handlers = null
  const wait = (ms) => new Promise((r) => setTimeout(r, ms))
  const make = (from, to, body, launch, carrier = 'arrow') => {
    const note = {
      id: `fake-${++seq}`, from, to, fromName: from === ECHO.id ? ECHO.name : me?.name,
      body, carrier, launch, at: new Date().toISOString(), opened: null,
    }
    notes.push(note)
    return note
  }

  return {
    kind: 'fake',
    useSecret: () => {},
    async register(name) {
      me = { id: 'me', name, code: 'CUPID-DEMO23', inbox: 'demo', secret: 'DEMO-DEMO-DEMO-DEMO' }
      // 처음 켜면 하나가 날아와 있다 — 눌러 보라고.
      setTimeout(() => {
        const n = make(ECHO.id, 'me', '안녕! 이렇게 화살로 쪽지가 와요. 눌러서 열고, 답장을 쏴 봐요 💘', { power: 0.55, angle: 0.7 })
        handlers?.onNote(n.id)
      }, 900)
      return me
    },
    me: async () => me ?? Promise.reject(new CupidError('bad_secret')),
    rename: async (name) => ({ ...(me = { ...me, name }) }),
    newCode: async () => me,
    newSecret: async () => me,
    deleteAccount: async () => { me = null; return true },
    friends: async () => [ECHO],
    addFriend: async () => { throw new CupidError('no_such_code') },
    removeFriend: async () => true,
    async send(to, body, launch, carrier) {
      await wait(150)
      const out = make('me', to, body, launch, carrier)
      if (to === ECHO.id) {
        setTimeout(() => {
          const back = make(ECHO.id, 'me', body, launch, carrier)
          handlers?.onNote(back.id)
        }, 1200)
      }
      return out
    },
    unread: async () => notes.filter((n) => n.to === 'me' && !n.opened),
    note: async (id) => notes.find((n) => n.id === id) ?? null,
    history: async (friend) => notes.filter((n) => n.from === friend || n.to === friend).slice(-50).reverse(),
    async open(id) {
      const n = notes.find((x) => x.id === id)
      if (n && !n.opened) n.opened = new Date().toISOString()
      return n ?? null
    },
    listen(_inbox, h) {
      handlers = h
      setTimeout(() => h.onLive(), 50)
    },
    stop: () => { handlers = null },
  }
}
