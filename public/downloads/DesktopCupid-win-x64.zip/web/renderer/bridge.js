// 셸과 이어지는 다리. 맥·윈도우 셸은 같은 꼴의 window.sneaky 를 만들어 준다.
// 브라우저로 열면(셸 없음) 여기서 흉내 낸다 — localStorage, 창 크기, 단축키.

export function bridge() {
  if (window.sneaky) return window.sneaky
  const handlers = {}
  const room = () => ({ x: 0, y: 0, w: window.innerWidth, h: window.innerHeight })
  window.addEventListener('resize', () => handlers.room?.(room()))
  setTimeout(() => handlers.room?.(room()), 0)
  window.addEventListener('keydown', (e) => {
    if (e.target.closest?.('input, textarea')) return
    const map = { f: ['friends'], r: ['recovery'], h: ['hidden'], s: ['sound'], m: ['shoot', 'echo'] }
    const hit = map[e.key.toLowerCase()]
    if (hit) handlers.menu?.(...hit)
  })
  const store = (k) => {
    try { return JSON.parse(localStorage.getItem(`cupid.${k}`)) } catch { return null }
  }
  return {
    platform: 'browser',
    getSecret: () => Promise.resolve(store('secret')),
    setSecret: (s) => localStorage.setItem('cupid.secret', JSON.stringify(s)),
    getState: () => Promise.resolve(store('state')),
    saveState: (s) => localStorage.setItem('cupid.state', JSON.stringify(s)),
    setHits: () => {},
    setKeyboard: () => {},
    capture: () => {},
    setMenu: () => {},
    copy: (text) => navigator.clipboard?.writeText(text),
    ready: () => {},
    onRoom: (h) => { handlers.room = h },
    onMenu: (h) => { handlers.menu = h },
  }
}
