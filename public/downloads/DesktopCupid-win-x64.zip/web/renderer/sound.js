// 소리는 파일 없이 그 자리에서 만든다 — 꽂히는 「퍽」과 시위 「팅」.
let ctx = null
const audio = () => (ctx ??= new (window.AudioContext || window.webkitAudioContext)())

export function thunk() {
  const a = audio()
  a.resume?.()
  const t = a.currentTime
  const osc = a.createOscillator()
  const gain = a.createGain()
  osc.type = 'sine'
  osc.frequency.setValueAtTime(190, t)
  osc.frequency.exponentialRampToValueAtTime(55, t + 0.12)
  gain.gain.setValueAtTime(0.0001, t)
  gain.gain.exponentialRampToValueAtTime(0.5, t + 0.005)
  gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.18)
  osc.connect(gain).connect(a.destination)
  osc.start(t)
  osc.stop(t + 0.2)
  // 나무에 박히는 딱 소리 — 아주 짧은 잡음.
  const buf = a.createBuffer(1, Math.floor(a.sampleRate * 0.03), a.sampleRate)
  const data = buf.getChannelData(0)
  for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length) ** 3
  const noise = a.createBufferSource()
  const ng = a.createGain()
  ng.gain.value = 0.35
  noise.buffer = buf
  noise.connect(ng).connect(a.destination)
  noise.start(t)
}

export function twang() {
  const a = audio()
  a.resume?.()
  const t = a.currentTime
  const osc = a.createOscillator()
  const gain = a.createGain()
  osc.type = 'triangle'
  osc.frequency.setValueAtTime(420, t)
  osc.frequency.exponentialRampToValueAtTime(160, t + 0.25)
  gain.gain.setValueAtTime(0.0001, t)
  gain.gain.exponentialRampToValueAtTime(0.25, t + 0.004)
  gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.3)
  osc.connect(gain).connect(a.destination)
  osc.start(t)
  osc.stop(t + 0.32)
}
