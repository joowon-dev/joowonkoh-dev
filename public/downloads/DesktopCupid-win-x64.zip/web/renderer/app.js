// 바탕화면 큐피트 — 렌더러. 서버 ↔ 셸 ↔ 화면.
//
// 화면은 주 화면 전체를 덮는 투명 창 하나다. 꽂힌 화살·활·카드가 다 여기 있고, 마우스는
// [data-hit] 이 붙은 것 위에서만 받는다 — 그 네모들을 셸에 알려 주면 셸이 그 위에서만 창이 마우스를 받게 한다.
import { landing } from '../game/landing.js'
import { createInbox } from '../game/inbox.js'
import { normalizeCode, normalizeSecret } from '../game/codes.js'
import { carrier } from '../carriers/index.js'
import { createServer } from '../net/server.js'
import { createFake } from '../net/fake.js'
import { bridge } from './bridge.js'
import { createBow } from './bow.js'
import { h, ago } from './dom.js'
import { thunk, twang } from './sound.js'

const shell = bridge()
const params = new URLSearchParams(location.search)
const config = await fetch('../config.json').then((r) => r.json()).catch(() => null)
const server = shell.platform === 'browser' && !params.has('real') ? createFake() : createServer(config)

const $arrows = document.getElementById('arrows')
const $ui = document.getElementById('ui')
const $quiver = document.getElementById('quiver')
const $toast = document.getElementById('toast')

const inbox = createInbox()
/** 쪽지 id → { el, to } (꽂힌 자리) */
const stuck = new Map()
let room = { x: 0, y: 0, w: window.innerWidth, h: window.innerHeight }
let me = null
let friends = []
let online = false
let settings = { sound: true, hidden: false }
let card = null // { el, kind, keyboard }

// ── 상태 저장 ─────────────────────────────────────────────────────

const saved = await shell.getState()
if (saved?.settings) settings = { ...settings, ...saved.settings }
const save = () => shell.saveState({ settings })

// ── 마우스를 받을 데 ───────────────────────────────────────────────

let hitsSent = ''
let hitsQueued = false
function sendHits() {
  hitsQueued = false
  const rects = []
  if (!settings.hidden || card) {
    for (const el of document.querySelectorAll('[data-hit]')) {
      if (el.closest('[hidden]')) continue
      const r = el.getBoundingClientRect()
      if (r.width < 1 || r.height < 1) continue
      rects.push({ x: Math.round(r.left - 4), y: Math.round(r.top - 4), w: Math.round(r.width + 8), h: Math.round(r.height + 8) })
    }
  }
  const text = JSON.stringify(rects)
  if (text === hitsSent) return
  hitsSent = text
  shell.setHits(rects)
}
const queueHits = () => {
  if (hitsQueued) return
  hitsQueued = true
  requestAnimationFrame(sendHits)
}
new MutationObserver(queueHits).observe(document.body, { subtree: true, childList: true, attributes: true })
window.addEventListener('resize', queueHits)

// ── 메뉴 막대에 알릴 것 ────────────────────────────────────────────

function updateMenu() {
  shell.setMenu({
    registered: !!me, name: me?.name ?? '', code: me?.code ?? '', online,
    friends: friends.map((f) => ({ id: f.id, name: f.name })),
    sound: settings.sound, hidden: settings.hidden, unread: inbox.visible().length + inbox.overflow(),
  })
}

// ── 알림 글 ────────────────────────────────────────────────────────

let toastTimer = 0
function toast(text, action) {
  clearTimeout(toastTimer)
  $toast.replaceChildren(h('span', {}, text))
  if (action) $toast.append(h('button', { class: 'pill', onclick: () => { hideToast(); action.run() } }, action.label))
  if (action) $toast.dataset.hit = ''
  else delete $toast.dataset.hit
  $toast.hidden = false
  $toast.animate([{ opacity: 0, transform: 'translate(-50%, 8px)' }, { opacity: 1, transform: 'translate(-50%, 0)' }], { duration: 200 })
  toastTimer = setTimeout(hideToast, action ? 7000 : 3200)
}
function hideToast() {
  $toast.hidden = true
}
const fail = (e) => toast(e?.message ?? String(e))

// ── 카드 ───────────────────────────────────────────────────────────

function closeCard() {
  if (!card) return
  const old = card
  card = null
  old.el.remove()
  if (old.keyboard) shell.setKeyboard(false)
  queueHits()
}

/** 카드 하나를 띄운다(한 번에 하나). at 이 있으면 그 점 가까이, 없으면 화면 위쪽 가운데. */
function showCard(kind, content, { keyboard = false, at = null, closable = true } = {}) {
  closeCard()
  const el = h('section', { class: `card card-${kind}`, dataset: { hit: '' } },
    closable ? h('button', { class: 'card-close', 'aria-label': '닫기', onclick: closeCard }, '×') : null,
    content)
  $ui.append(el)
  const r = el.getBoundingClientRect()
  let x = room.x + (room.w - r.width) / 2
  let y = room.y + Math.max(40, room.h * 0.16)
  if (at) {
    x = at.x - r.width / 2
    y = at.y + 26
    if (y + r.height > room.y + room.h - 16) y = at.y - r.height - 26
  }
  x = Math.min(Math.max(x, room.x + 16), room.x + room.w - r.width - 16)
  y = Math.min(Math.max(y, room.y + 16), room.y + room.h - r.height - 16)
  el.style.left = `${x}px`
  el.style.top = `${y}px`
  el.animate([{ opacity: 0, transform: 'translateY(10px) scale(.97)' }, { opacity: 1, transform: 'none' }],
    { duration: 200, easing: 'cubic-bezier(.2,.9,.3,1.2)' })
  card = { el, kind, keyboard }
  if (keyboard) {
    shell.setKeyboard(true)
    setTimeout(() => el.querySelector('input, textarea')?.focus(), 30)
  }
  queueHits()
  return el
}

window.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && card?.kind !== 'welcome') closeCard()
})

/** 단추를 누르는 동안 막아 두고, 끝나면 푼다. */
async function busy(button, work) {
  button.disabled = true
  try { return await work() } catch (e) { fail(e) } finally { button.disabled = false }
}

// 처음 — 이름을 정하거나 복구 코드로 돌아온다.
function welcomeCard(mode = 'new') {
  const input = h('input', { maxlength: mode === 'new' ? 20 : 19, placeholder: mode === 'new' ? '친구에게 보일 이름' : 'XXXX-XXXX-XXXX-XXXX' })
  const go = h('button', { class: 'primary' }, mode === 'new' ? '시작하기' : '돌아가기')
  const submit = () => busy(go, async () => {
    if (mode === 'new') {
      const name = input.value.trim()
      if (!name) return input.focus()
      const made = await server.register(name)
      shell.setSecret(made.secret)
      await signedIn(made)
      closeCard()
      recoveryCard(true)
    } else {
      const secret = normalizeSecret(input.value)
      if (!secret) return toast('복구 코드는 16자예요')
      server.useSecret(secret)
      const back = await server.me()
      shell.setSecret(secret)
      await signedIn(back)
      closeCard()
      toast(`다시 왔어요, ${back.name}`)
    }
  })
  go.addEventListener('click', submit)
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit() })
  showCard('welcome', h('div', {},
    h('div', { class: 'card-mark' }, '🏹'),
    h('h2', {}, mode === 'new' ? '바탕화면 큐피트' : '복구 코드로 돌아가기'),
    h('p', { class: 'muted' }, mode === 'new'
      ? '쪽지를 활로 쏘면 친구 바탕화면에 꽂혀요. 세게 쏠수록 깊이.'
      : '전에 받아 둔 복구 코드를 넣으면 친구와 안 읽은 쪽지가 그대로 돌아와요.'),
    h('div', { class: 'row' }, input, go),
    h('button', { class: 'link', onclick: () => welcomeCard(mode === 'new' ? 'restore' : 'new') },
      mode === 'new' ? '복구 코드가 있어요' : '처음이에요')), { keyboard: true, closable: false })
}

function codeBox(text, label) {
  return h('div', { class: 'code-box' },
    h('code', {}, text),
    h('button', { class: 'pill', onclick: (e) => { shell.copy(text); e.target.textContent = '복사했어요'; } }, label ?? '복사'))
}

function recoveryCard(first = false) {
  if (!me) return welcomeCard()
  const body = h('div', {},
    h('h2', {}, first ? '복구 코드를 챙겨 두세요' : '복구 코드'),
    h('p', { class: 'muted' }, '앱을 다시 깔거나 다른 컴퓨터에서 쓸 때 이 코드를 넣으면 친구와 쪽지가 그대로 와요. 아무에게도 보여 주지 마세요.'),
    h('div', { class: 'secret-slot' }, h('p', { class: 'muted' }, '불러오는 중…')))
  showCard('recovery', body)
  shell.getSecret().then((secret) => {
    const slot = body.querySelector('.secret-slot')
    const renew = h('button', { class: 'link danger' }, '새 코드 받기(지금 코드는 못 쓰게 돼요)')
    renew.addEventListener('click', () => busy(renew, async () => {
      const fresh = await server.newSecret()
      shell.setSecret(fresh.secret)
      recoveryCard()
      toast('새 복구 코드를 받았어요. 다른 컴퓨터는 새 코드를 넣어야 해요')
    }))
    slot.replaceChildren(codeBox(secret ?? '—'), first ? h('button', { class: 'primary wide', onclick: friendsCard }, '친구 추가하러 가기') : renew)
  })
}

function friendsCard() {
  if (!me) return welcomeCard()
  const input = h('input', { placeholder: 'CUPID-XXXXXX', maxlength: 14 })
  const add = h('button', { class: 'primary' }, '추가')
  const submit = () => busy(add, async () => {
    const code = normalizeCode(input.value)
    if (!code) return toast('친구 코드는 CUPID- 뒤에 6자예요')
    const friend = await server.addFriend(code)
    friends = await server.friends()
    updateMenu()
    friendsCard()
    toast(`${friend.name}와 친구가 됐어요 💞`)
  })
  add.addEventListener('click', submit)
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit() })

  const nameInput = h('input', { value: me.name, maxlength: 20, class: 'name-input' })
  const saveName = async () => {
    const name = nameInput.value.trim()
    if (!name || name === me.name) return
    try {
      me = { ...me, ...(await server.rename(name)) }
      updateMenu()
      toast('이름을 바꿨어요')
    } catch (e) { fail(e); nameInput.value = me.name }
  }
  nameInput.addEventListener('change', saveName)
  nameInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') nameInput.blur() })

  const list = friends.length
    ? h('ul', { class: 'friends' }, friends.map((f) => h('li', {},
        h('span', { class: 'friend-name' }, f.name),
        h('button', { class: 'pill primary', onclick: () => composeCard(f.id) }, '쪽지 쓰기'),
        h('button', { class: 'icon', title: '친구 끊기', onclick: (e) => unfriend(f, e.target) }, '✕'))))
    : h('p', { class: 'muted empty' }, '아직 친구가 없어요. 내 코드를 보내 주거나 친구 코드를 넣어요.')

  const renewCode = h('button', { class: 'link' }, '새 코드 받기')
  renewCode.addEventListener('click', () => busy(renewCode, async () => {
    me = { ...me, ...(await server.newCode()) }
    friendsCard()
    toast('새 코드예요. 옛 코드로는 이제 못 맺어요')
  }))

  showCard('friends', h('div', {},
    h('div', { class: 'me-line' }, h('span', { class: 'muted' }, '내 이름'), nameInput,
      h('span', { class: `dot ${online ? 'on' : 'off'}`, title: online ? '이어져 있어요' : '서버에 안 이어져 있어요' })),
    h('h3', {}, '내 코드'),
    codeBox(me.code),
    h('p', { class: 'muted small' }, '이 코드를 받은 사람은 바로 친구가 돼요. ', renewCode),
    h('h3', {}, '친구 추가'),
    h('div', { class: 'row' }, input, add),
    h('h3', {}, `친구 ${friends.length}`),
    list), { keyboard: true })
}

async function unfriend(friend, button) {
  if (button.dataset.sure !== '1') {
    button.dataset.sure = '1'
    button.textContent = '끊기?'
    setTimeout(() => { button.dataset.sure = ''; button.textContent = '✕' }, 2500)
    return
  }
  await busy(button, async () => {
    await server.removeFriend(friend.id)
    friends = friends.filter((f) => f.id !== friend.id)
    updateMenu()
    friendsCard()
  })
}

function composeCard(friendId, draft = '') {
  const friend = friends.find((f) => f.id === friendId)
  if (!friend) return friendsCard()
  const text = h('textarea', { maxlength: 200, rows: 4, placeholder: `${friend.name}에게 쪽지…` })
  text.value = draft
  const count = h('span', { class: 'count' }, `${draft.length}/200`)
  text.addEventListener('input', () => { count.textContent = `${text.value.length}/200` })
  const load = h('button', { class: 'primary' }, '🏹 장전')
  const arm = () => {
    const body = text.value.trim()
    if (!body) return text.focus()
    closeCard()
    bow.arm({ to: friend.id, toName: friend.name, body })
  }
  load.addEventListener('click', arm)
  text.addEventListener('keydown', (e) => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) arm() })

  const history = h('ul', { class: 'history' }, h('li', { class: 'muted' }, '불러오는 중…'))
  showCard('compose', h('div', {},
    h('h2', {}, `${friend.name}에게`),
    text,
    h('div', { class: 'row end' }, count, h('span', { class: 'muted small' }, '⌘↵'), load),
    h('h3', {}, '주고받은 쪽지'),
    history), { keyboard: true })
  server.history(friendId).then((notes) => {
    history.replaceChildren(...(notes.length ? notes.map((n) => {
      const mine = n.from === me.id
      const li = h('li', { class: mine ? 'mine' : 'theirs' },
        h('div', { class: 'bubble' }, n.body),
        h('div', { class: 'meta' }, ago(n.at), mine ? (n.opened ? ' · 읽음' : ' · 아직 안 읽음') : (n.opened ? '' : ' · 안 뽑은 화살')))
      if (!mine && !n.opened) li.addEventListener('click', () => openNote(n.id))
      return li
    }) : [h('li', { class: 'muted' }, '아직 없어요. 첫 화살을 쏴 봐요!')]))
    queueHits()
  }, fail)
}

function noteCard(note, at) {
  const from = friends.find((f) => f.id === note.from)
  showCard('note', h('div', {},
    h('div', { class: 'note-head' }, h('strong', {}, note.fromName ?? from?.name ?? '친구'), h('span', { class: 'muted' }, ago(note.at))),
    h('p', { class: 'note-body' }, note.body),
    h('div', { class: 'row end' },
      h('button', { class: 'pill', onclick: closeCard }, '닫기'),
      from ? h('button', { class: 'pill primary', onclick: () => composeCard(from.id) }, '💘 답장 쏘기') : null)), { at })
}

function deleteCard() {
  if (!me) return
  const sure = h('button', { class: 'primary danger' }, '정말 지우기')
  sure.addEventListener('click', () => busy(sure, async () => {
    await server.deleteAccount()
    shell.setSecret(null)
    signedOut()
    toast('계정을 지웠어요')
  }))
  showCard('delete', h('div', {},
    h('h2', {}, '계정을 지울까요?'),
    h('p', { class: 'muted' }, '서버에서 내 이름, 친구, 주고받은 쪽지가 모두 지워져요. 되돌릴 수 없어요. 친구 목록에서도 사라져요.'),
    h('div', { class: 'row end' }, h('button', { class: 'pill', onclick: closeCard }, '그만두기'), sure)))
}

// ── 활 ─────────────────────────────────────────────────────────────

const bow = createBow({
  layer: $ui,
  capture: (on) => shell.capture(on),
  onCancel(armed) {
    bow.disarm()
    composeCard(armed.to, armed.body)
  },
  async onFire(shot) {
    if (settings.sound) twang()
    const art = carrier('arrow')
    const el = art.element({ fromName: me?.name })
    el.querySelector('.arrow-grab')?.remove()
    $arrows.append(el)
    const flight = art.flyOut(el, shot.tip, shot.angle, { w: window.innerWidth, h: window.innerHeight })
    const launch = { power: Math.round(shot.power * 1000) / 1000, angle: Math.round(shot.angle * 1000) / 1000 }
    try {
      await server.send(shot.to, shot.body, launch, 'arrow')
      await flight.finished.catch(() => {})
      el.remove()
      bow.disarm()
      toast(`💘 ${shot.toName}에게 쐈어요 (세기 ${Math.round(shot.power * 100)}%)`)
    } catch (e) {
      flight.cancel()
      art.flop(el, shot.tip).finished.then(() => el.remove(), () => el.remove())
      bow.rearm()
      toast(`못 보냈어요 — ${e.message}. 다시 당겨서 쏘면 돼요`)
    }
  },
})

// ── 받은 화살 ──────────────────────────────────────────────────────

function taken() {
  return [...stuck.values()].map((s) => s.to)
}

function land(note, { quiet = false } = {}) {
  const art = carrier(note.carrier)
  const launch = note.launch ?? {}
  const where = landing({
    power: launch.power ?? 0.5, angle: launch.angle ?? Math.PI / 4, seed: note.id, room, taken: taken(),
  })
  const el = art.element(note)
  el.dataset.note = note.id
  el.querySelector('.arrow-grab').addEventListener('click', () => openNote(note.id))
  $arrows.append(el)
  stuck.set(note.id, { el, to: where.to })
  if (quiet) {
    art.place(el, where.to, where.tilt)
    art.stick(el)
  } else {
    const flight = art.flyIn(el, where)
    flight.finished.then(() => { if (settings.sound) thunk() }, () => {})
  }
}

function showQuiver() {
  const n = inbox.overflow()
  $quiver.hidden = n === 0
  $quiver.querySelector('b').textContent = `+${n}`
}

/** 들어온 쪽지 하나. 화면에 꽂거나 화살통에 넣는다. */
function receive(note, opts) {
  if (!note || note.opened || note.to !== me?.id) return
  // 나를 코드로 맺은 사람은 내 목록에 아직 없다 — 그 사람의 화살이 오면 목록을 다시 받는다.
  if (!friends.some((f) => f.id === note.from)) {
    server.friends().then((list) => { friends = list; updateMenu() }, () => {})
  }
  const where = inbox.add(note)
  if (where === 'new') land(note, opts)
  showQuiver()
  updateMenu()
}

/** 화살을 뽑는다(내가 열었거나, 다른 기기에서 열었다). */
function pluck(id) {
  const s = stuck.get(id)
  const promoted = inbox.remove(id)
  if (s) {
    stuck.delete(id)
    s.el.animate([{ opacity: 1 }, { opacity: 0, translate: '0 -18px' }], { duration: 260, easing: 'ease-in' })
      .finished.then(() => s.el.remove(), () => s.el.remove())
  }
  if (promoted) land(promoted)
  showQuiver()
  updateMenu()
}

async function openNote(id) {
  const local = inbox.get(id)
  const at = stuck.get(id)?.to
  try {
    const note = local ?? (await server.note(id))
    if (!note) return
    noteCard(note, at)
    pluck(id)
    server.open(id).catch(fail)
  } catch (e) { fail(e) }
}

// 화살통을 누르면 가장 먼저 온 것부터 하나씩 연다.
$quiver.addEventListener('click', () => {
  const first = inbox.visible()[0]
  if (first) openNote(first.id)
})

/** 안 읽은 것을 다시 물어 끊긴 사이를 메운다. 여럿이면 하나씩 날아 들어온다. */
let refilling = false
async function refill() {
  if (refilling || !me) return
  refilling = true
  try {
    server.friends().then((list) => { friends = list; updateMenu() }, () => {})
    const list = await server.unread()
    // 화면에 자리가 있는 만큼만 하나씩 날아 들어오고, 나머지는 곧장 화살통으로.
    let delay = 0
    let free = 20 - inbox.visible().length
    for (const note of list) {
      if (inbox.has(note.id)) continue
      if (free-- > 0) {
        setTimeout(() => receive(note), delay)
        delay += 380
      } else {
        setTimeout(() => receive(note), delay)
      }
    }
  } catch (e) {
    online = false
  } finally {
    refilling = false
  }
}

// ── 로그인 ─────────────────────────────────────────────────────────

async function signedIn(who) {
  me = { ...(me ?? {}), ...who }
  friends = await server.friends().catch(() => [])
  updateMenu()
  server.listen(me.inbox, {
    onNote: async (id) => {
      if (inbox.has(id)) return
      try { receive(await server.note(id)) } catch {}
    },
    onOpened: (id) => { if (inbox.has(id)) pluck(id) },
    onLive: () => {
      online = true
      updateMenu()
      refill()
    },
    onDown: () => {
      online = false
      updateMenu()
    },
  })
}

function signedOut() {
  server.stop()
  me = null
  friends = []
  for (const id of [...stuck.keys()]) pluck(id)
  closeCard()
  if (bow.armed) bow.disarm()
  updateMenu()
  welcomeCard()
}

async function boot() {
  const secret = await shell.getSecret()
  if (!secret) return welcomeCard()
  server.useSecret(secret)
  for (let wait = 2000; ; wait = Math.min(wait * 2, 60000)) {
    try {
      await signedIn(await server.me())
      return
    } catch (e) {
      if (e.code === 'bad_secret') {
        shell.setSecret(null)
        toast('계정을 찾을 수 없어요. 다시 시작하거나 복구 코드를 넣어 주세요')
        return welcomeCard()
      }
      online = false
      updateMenu()
      await new Promise((r) => setTimeout(r, wait))
    }
  }
}

// ── 셸에서 오는 것 ─────────────────────────────────────────────────

function applyHidden() {
  document.body.classList.toggle('hidden-arrows', settings.hidden)
  queueHits()
}

shell.onRoom((next) => {
  room = next
  bow.setRoom(room)
  queueHits()
})

shell.onMenu((action, arg) => {
  switch (action) {
    case 'shoot': return me ? composeCard(arg) : welcomeCard()
    case 'friends':
      if (!me) return welcomeCard()
      return server.friends().then((list) => { friends = list; updateMenu() }, () => {}).then(friendsCard)
    case 'recovery': return me ? recoveryCard() : welcomeCard('restore')
    case 'delete': return deleteCard()
    case 'sound':
      settings.sound = !settings.sound
      break
    case 'hidden':
      settings.hidden = !settings.hidden
      applyHidden()
      break
    case 'refresh': return refill()
    default: return
  }
  save()
  updateMenu()
})

bow.setRoom(room)
applyHidden()
updateMenu()
shell.ready()
boot()

// 디버그: 셸의 eval 로 부른다.
window.__cupidDebug = () => ({ me, friends, online, stuck: [...stuck.keys()], overflow: inbox.overflow(), hits: hitsSent, room })
