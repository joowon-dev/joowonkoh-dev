// 화면 맨 아래 발사대. 바탕화면 위에 보이는 것이라고는 이것과 불꽃뿐이다.
//
// 발사대는 물리를 갖지 않는다 — 어디에 서 있고, 어느 쪽을 겨누고 있고, 방금 쐈는지만
// 안다. 포탄이 실제로 어떻게 날아가는지는 engine.js 가 정한다.

import { PAD_COUNT, PAD_FLASH } from './constants.js'

/**
 * @typedef {object} Pad
 * @property {number} x 관 입구의 가로 위치
 * @property {number} baseY 받침이 놓인 높이 (화면 바닥)
 * @property {number} muzzleY 관 입구의 높이 — 포탄이 여기서 나온다
 * @property {number} tilt 겨누는 각도 (라디안, 0 이 수직 위)
 * @property {number} flash 발사 섬광이 남은 시간
 */

/** 발사대 높이. 화면을 거의 안 가리도록 작게. */
export const PAD_HEIGHT = 26

/**
 * 발사대를 화면 폭에 고르게 세운다. 양 끝은 화면 밖으로 나가지 않게 안쪽으로 들인다.
 *
 * 바깥쪽 발사대일수록 바깥으로 기울인다 — 전부 수직으로 쏘면 불꽃이 화면 가운데
 * 세로줄에만 몰려서 넓은 화면이 텅 비어 보인다.
 *
 * @returns {Pad[]}
 */
export function createPads(width, height, count = PAD_COUNT) {
  const margin = width * 0.07
  const span = width - margin * 2
  const pads = []
  for (let i = 0; i < count; i += 1) {
    // count 가 1 이면 0 으로 나누게 된다. 그때는 가운데 하나.
    const f = count === 1 ? 0.5 : i / (count - 1)
    const fromCenter = (f - 0.5) * 2 // −1 … 1
    pads.push({
      x: margin + span * f,
      baseY: height,
      muzzleY: height - PAD_HEIGHT,
      tilt: fromCenter * 0.22,
      flash: 0,
    })
  }
  return pads
}

/** 이 발사대가 방금 쐈다고 표시한다. */
export function firePad(pad) {
  pad.flash = PAD_FLASH
}

/** 섬광을 사그라뜨린다. */
export function stepPads(pads, dt) {
  for (const pad of pads) {
    if (pad.flash > 0) pad.flash = Math.max(0, pad.flash - dt)
  }
}

/** 섬광 밝기 0~1. */
export function padGlow(pad) {
  return pad.flash / PAD_FLASH
}

/** 각본이 범위 밖 번호를 써도 앱이 죽지 않게, 있는 발사대로 접어 넣는다. */
export function padAt(pads, index) {
  if (pads.length === 0) return null
  const i = ((Math.round(index) % pads.length) + pads.length) % pads.length
  return pads[i]
}
