// 각본. **여기만 고치면 쇼가 바뀐다.**
//
// 큐 하나는 포탄 한 발이다.
//   at     쇼 시작으로부터 몇 초에 쏘나
//   pad    몇 번 발사대에서 쏘나 (0 이 맨 왼쪽. 범위를 넘으면 접어 넣는다)
//   height 화면 높이의 몇 %까지 올라가서 터지나 (0.6 = 화면 높이의 60%)
//   x      터질 가로 위치 (0 = 왼쪽 끝, 1 = 오른쪽 끝). 안 적으면 발사대가 겨눈 쪽
//   trail  올라가는 동안의 꼬리 색
//   burst  터짐 사양 — type, colors, count, speed, life, size, crackle,
//                      text, width, textHeight
//
// 터짐 종류: peony(국화) · ring(고리) · star(별) · willow(수양버들) · heart(하트) · text(글자)
//
// 쇼의 순서:
//   ① 한 줄로 쏘아 올리는 일제 발사 넉 줄
//   ② I → LOVE → YOU 한 낱말씩
//   ③ 하트
//   ④ 사랑해, 양옆에 하트 둘
//   ⑤ 대피날레 — 빠른 연발 뒤 일제 발사 다섯 줄
//
// 글자 큐의 count 가 유난히 크다(520~1400). 획이 적은 「I」는 520 이면 충분하지만
// 한글은 획이 많아서 400 개쯤으로는 점만 흩뿌려진 것처럼 보이고 글자로 안 읽힌다 —
// 전부 실제로 띄워 보고 정한 값이다.

import { PAD_COUNT } from './constants.js'

// ─────────────────────────────────────────────────────────────
// 문구 — 바꾸고 싶으면 여기만 고친다. 한글도 이모지도 폰트가 그릴 수 있으면 다 된다.
// ─────────────────────────────────────────────────────────────
export const TEXTS = {
  i: 'I',
  love: 'LOVE',
  you: 'YOU',
  last: '사랑해',
}

// 색 조합. 이름을 각본에서 부른다.
const PALETTE = {
  rose: ['#ff5c8a', '#ff9ec4', '#ffd6e6', '#ff2e6d'],
  gold: ['#ffd76a', '#ffb43d', '#fff3c4', '#ff8a2b'],
  ice: ['#8ad8ff', '#c9ecff', '#ffffff', '#5bb8ff'],
  mint: ['#7dffcf', '#c8fff0', '#3ee8ac', '#ffffff'],
  violet: ['#c08cff', '#e3ccff', '#8f5cff', '#ffffff'],
  white: ['#ffffff', '#fff6e0', '#dfe9ff'],
}

/** 반복을 줄이려고 쓰는 도우미. 각본 자체는 그대로 표로 읽힌다. */
const shot = (at, pad, height, type, palette, extra = {}) => ({
  at,
  pad,
  height,
  trail: extra.trail ?? '#ffd9a0',
  x: extra.x,
  burst: { type, colors: PALETTE[palette], ...extra.burst },
})

/**
 * 일제 발사 — 발사대 아홉 개가 **같은 순간에 한 줄로** 쏜다. 이 쇼의 시작과 끝이 이것이다.
 *
 * 가로 위치를 발사대에 맡기지 않고 직접 적는다. 발사대가 겨눈 각도에 맡기면 높이 쏠수록
 * 바깥으로 더 벌어져서, 양 끝 두 발이 화면 밖에서 터진다.
 *
 * 높이를 발사대마다 조금씩 어긋나게 준다 — 아홉 발이 정확히 같은 높이에서 터지면
 * 불꽃놀이가 아니라 자로 그은 줄처럼 보인다.
 */
function wave(at, height, palettes, options = {}) {
  const { type = 'peony', count = 150, speed = 300, trail = '#ffd9a0' } = options
  const out = []
  for (let pad = 0; pad < PAD_COUNT; pad += 1) {
    out.push(shot(
      at,
      pad,
      height + ((pad * 3) % 5) / 45,
      type,
      palettes[pad % palettes.length],
      { x: 0.08 + (pad * 0.84) / (PAD_COUNT - 1), trail, burst: { count, speed } },
    ))
  }
  return out
}

/** 빠른 연발. 좌우를 오가며 한 발씩. */
function rapid(start, count, gap) {
  const types = ['peony', 'ring', 'star', 'peony', 'willow', 'peony']
  const palettes = ['rose', 'gold', 'ice', 'violet', 'mint', 'white']
  const out = []
  for (let i = 0; i < count; i += 1) {
    out.push(shot(
      start + i * gap,
      i % 2 === 0 ? 1 + (i % 3) : 7 - (i % 3),
      0.42 + ((i * 7) % 9) / 30,
      types[i % types.length],
      palettes[i % palettes.length],
      { x: 0.12 + ((i * 5) % 9) * 0.095, burst: { count: 180, speed: 310 } },
    ))
  }
  return out
}

/** @type {object[]} 시간순. stepWorld 가 앞에서부터 훑기 때문에 순서가 뒤집히면 안 된다. */
export const SHOW = [
  // ── ① 한 줄로 쏘아 올린다. 넉 줄이 잇달아 올라간다
  ...wave(1.0, 0.50, ['gold', 'white', 'gold']),
  ...wave(2.3, 0.60, ['rose', 'ice', 'rose', 'white']),
  ...wave(3.6, 0.46, ['violet', 'mint', 'violet']),
  ...wave(4.9, 0.66, ['gold', 'rose', 'ice', 'mint'], { type: 'ring', count: 130 }),

  // ── ② I → LOVE → YOU. 셋 다 같은 자리, 같은 높이로 세워서 한 마디처럼 읽히게 한다.
  //     크기를 width 가 아니라 textHeight 로 주는 이유는 engine.js 의 textScale() 에 있다.
  shot(11.0, 4, 0.58, 'text', 'white', {
    x: 0.5,
    trail: '#ffffff',
    burst: { text: TEXTS.i, textHeight: 0.20, count: 520, size: 2.6, life: 3.0 },
  }),
  shot(15.5, 4, 0.58, 'text', 'ice', {
    x: 0.5,
    trail: '#c9ecff',
    burst: { text: TEXTS.love, textHeight: 0.20, count: 1400, size: 2.5, life: 3.0 },
  }),
  shot(20.0, 4, 0.58, 'text', 'gold', {
    x: 0.5,
    trail: '#ffd76a',
    burst: { text: TEXTS.you, textHeight: 0.20, count: 1200, size: 2.5, life: 3.0 },
  }),

  // ── ③ 하트 하나. 앞뒤를 비워 둔다 — 여기가 쇼에서 제일 조용해야 하는 지점이다
  shot(25.5, 4, 0.62, 'heart', 'rose', {
    x: 0.5,
    trail: '#ff9ec4',
    burst: { count: 340, speed: 300, life: 2.8, size: 2.5 },
  }),

  // ── ④ 사랑해, 양옆에 하트 둘. 글자가 서는 순간에 맞춰 같이 터진다
  shot(31.5, 4, 0.58, 'text', 'rose', {
    x: 0.5,
    trail: '#ffd6e6',
    burst: { text: TEXTS.last, width: 0.40, count: 1400, size: 2.6, life: 4.2 },
  }),
  shot(31.6, 1, 0.52, 'heart', 'rose', { x: 0.18, burst: { count: 200, speed: 250 } }),
  shot(31.6, 7, 0.52, 'heart', 'violet', { x: 0.82, burst: { count: 200, speed: 250 } }),

  // ── ⑤ 대피날레. 빠른 연발로 몰아치다가, 마지막은 다시 한 줄씩 다섯 줄
  ...rapid(38.0, 26, 0.34),
  ...wave(47.5, 0.48, ['rose', 'gold', 'ice']),
  ...wave(48.7, 0.60, ['violet', 'mint', 'white']),
  ...wave(49.9, 0.44, ['gold', 'rose'], { type: 'star', count: 170 }),
  ...wave(51.1, 0.64, ['ice', 'violet', 'gold', 'rose']),
  ...wave(52.3, 0.54, ['rose', 'gold', 'white', 'mint'], { type: 'willow', count: 150 }),
]

/**
 * 각본이 쓰는 글자를 모은다. 렌더러는 이 목록만큼만 마스크를 만들면 된다 —
 * 각본에 문구를 추가하면 마스크도 저절로 따라온다.
 */
export function collectTexts(script = SHOW) {
  const seen = new Set()
  for (const cue of script) {
    const text = cue.burst?.text
    if (typeof text === 'string' && text.length > 0) seen.add(text)
  }
  return [...seen]
}
