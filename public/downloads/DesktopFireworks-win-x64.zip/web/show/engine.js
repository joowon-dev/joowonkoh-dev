// 쇼의 월드. 각본을 시간순으로 소비해 포탄을 쏘고, 포탄이 터지면 파티클을 만들고,
// 소리 이벤트를 쌓아 둔다.
//
// 이 파일은 소리를 내지 않고 그림도 그리지 않는다 — `world.sounds` 에 이벤트를 쌓고,
// `world.particles` 를 들고 있을 뿐이다. 재생과 그리기는 렌더러의 일이다. 그래야
// 순수성이 유지되고, 같은 시드로 돌리면 언제나 같은 쇼가 나온다.

import {
  GRAVITY, BURST_DRAG, SHELL_DRAG, MAX_PARTICLES,
  TEXT_HOLD, TEXT_DRAG, TEXT_GRAVITY, SOUND_DELAY_PER_PX, LOOP_GAP,
} from './constants.js'
import { makeRng, range, pick } from './rng.js'
import { createParticle, stepParticle, isAlive } from './particles.js'
import { directionsFor, sampleMask } from './shapes.js'
import { createPads, stepPads, firePad, padAt } from './launcher.js'

/** '#ff5c8a' → [255, 92, 138]. 순수하게 두려고 DOM 색 파서를 쓰지 않는다. */
export function hexToRgb(hex) {
  const s = hex.replace('#', '')
  const full = s.length === 3 ? s[0] + s[0] + s[1] + s[1] + s[2] + s[2] : s
  const n = Number.parseInt(full, 16)
  if (!Number.isFinite(n)) return [255, 255, 255]
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255]
}

/**
 * 종류마다 다른 기본값. 각본이 값을 적으면 그게 이긴다.
 * 수양버들만 유난히 다르다 — 오래 살고 항력이 약해서 중력이 길게 늘어뜨린다.
 */
const BURST_DEFAULTS = {
  peony: { count: 150, speed: 300, life: 1.9, drag: BURST_DRAG, size: 1.9, twinkle: 0 },
  ring: { count: 130, speed: 320, life: 1.7, drag: BURST_DRAG, size: 1.8, twinkle: 0 },
  star: { count: 170, speed: 320, life: 1.8, drag: BURST_DRAG, size: 1.9, twinkle: 0 },
  heart: { count: 220, speed: 300, life: 2.3, drag: BURST_DRAG, size: 2.1, twinkle: 0 },
  willow: { count: 130, speed: 250, life: 3.4, drag: 0.42, size: 2.0, twinkle: 0 },
  text: { count: 420, speed: 0, life: TEXT_HOLD + 2.0, drag: TEXT_DRAG, size: 2.0, twinkle: 0 },
}

/**
 * 월드를 만든다.
 *
 * @param {object} options
 * @param {number} options.width @param {number} options.height 화면 크기(px)
 * @param {number} [options.seed] 같은 시드면 같은 쇼가 나온다
 * @param {object[]} options.script 각본 (script.js 참고)
 * @param {Record<string, {data: ArrayLike<number>, width: number, height: number}>} [options.masks]
 *   글자 문구 → 알파 마스크. 렌더러가 캔버스로 만들어 넣어 준다.
 */
export function createWorld({ width, height, seed = 20260906, script, masks = {} }) {
  return {
    width,
    height,
    seed,
    rng: makeRng(seed),
    script,
    masks,
    time: 0,
    cursor: 0,
    pads: createPads(width, height),
    shells: [],
    particles: [],
    /** 렌더러가 매 프레임 비워 간다. {type, delay, volume, size} */
    sounds: [],
    /** 각본을 한 바퀴 돈 횟수. 디버깅용. */
    loops: 0,
  }
}

/** 화면 크기가 바뀌었다 (모니터를 갈아 끼웠거나 해상도가 바뀌었거나). */
export function resizeWorld(world, width, height) {
  world.width = width
  world.height = height
  world.pads = createPads(width, height)
}

/** 각본을 처음부터 다시. 이미 떠 있는 불꽃은 그대로 두고 사그라들게 한다. */
export function restartWorld(world) {
  world.time = 0
  world.cursor = 0
  world.rng = makeRng(world.seed)
}

/** 각본의 마지막 큐 시각. 여기서 LOOP_GAP 만큼 더 지나면 다시 돈다. */
function scriptEnd(script) {
  let end = 0
  for (const cue of script) if (cue.at > end) end = cue.at
  return end
}

/**
 * 한 스텝. 반드시 고정 dt 로 부른다 — 프레임 시간을 그대로 넣으면 기계마다 결과가
 * 달라진다.
 */
export function stepWorld(world, dt) {
  world.time += dt

  fireDueCues(world)
  stepShells(world, dt)
  stepParticles(world, dt)
  stepPads(world.pads, dt)

  if (world.time > scriptEnd(world.script) + LOOP_GAP) {
    world.loops += 1
    restartWorld(world)
  }
}

/** 시각이 된 큐를 전부 쏜다. 각본은 시간순이라고 본다. */
function fireDueCues(world) {
  while (world.cursor < world.script.length && world.script[world.cursor].at <= world.time) {
    launch(world, world.script[world.cursor])
    world.cursor += 1
  }
}

/**
 * 포탄 하나를 쏜다.
 *
 * 각본은 「화면 높이의 몇 %까지 올라가나」(`height`)만 적는다. 초기 속도와 도화선 시간은
 * 거기서 풀린다: `v0 = sqrt(2·g·h)`, 꼭대기까지 `t = v0/g`. 가로 목표(`x`)가 있으면
 * 그 시간 안에 도달하도록 가로 속도를 정한다 — 중력이 가로에 영향을 주지 않으니
 * 그냥 나누면 된다.
 */
function launch(world, cue) {
  const pad = padAt(world.pads, cue.pad ?? 0)
  if (!pad) return
  firePad(pad)

  const rise = Math.max(40, (cue.height ?? 0.55) * world.height)
  const vy = -Math.sqrt(2 * GRAVITY * rise)
  const fuse = -vy / GRAVITY

  // 가로 목표. 안 적으면 발사대가 겨누는 쪽으로 살짝 흘러간다.
  const targetX = cue.x === undefined
    ? pad.x + Math.tan(pad.tilt) * rise
    : cue.x * world.width
  const vx = (targetX - pad.x) / fuse

  const rgb = hexToRgb(cue.trail ?? '#ffd9a0')
  const shell = createParticle({
    x: pad.x, y: pad.muzzleY, vx, vy,
    life: fuse, drag: SHELL_DRAG, gravity: GRAVITY,
    rgb, size: 2.2, twinkle: 26, phase: range(world.rng, 0, 6.283),
  })

  world.shells.push({ p: shell, burst: cue.burst ?? { type: 'peony' } })
  world.sounds.push({ type: 'launch', delay: 0, volume: 0.5, size: 0 })
}

function stepShells(world, dt) {
  const alive = []
  for (const shell of world.shells) {
    stepParticle(shell.p, dt)
    if (isAlive(shell.p)) {
      alive.push(shell)
    } else {
      explode(world, shell.p.x, shell.p.y, shell.burst)
    }
  }
  world.shells = alive
}

function stepParticles(world, dt) {
  const alive = []
  for (const p of world.particles) {
    stepParticle(p, dt)
    // 화면 아래로 완전히 빠진 파티클은 더 볼 일이 없다.
    if (isAlive(p) && p.y < world.height + 60) alive.push(p)
  }
  world.particles = alive
}

/**
 * 터진다. 두 가지 방식이 있다.
 *
 * **방향 방식** (하트·별·고리·국화·수양버들) — 모양이 주는 단위 벡터에 속도를 곱해
 * 그대로 쏜다. 그 뒤는 중력과 항력에 맡긴다.
 *
 * **목표 방식** (글자) — 지수 항력에서 총 이동거리가 `v0/drag` 로 수렴하는 성질을
 * 거꾸로 쓴다. 목표점까지의 변위에 항력 계수를 곱한 속도를 주면 파티클이 정확히 그
 * 자리에 가서 선다. 반복도 보정도 없다.
 */
export function explode(world, x, y, burst) {
  const type = burst.type ?? 'peony'
  const spec = { ...(BURST_DEFAULTS[type] ?? BURST_DEFAULTS.peony), ...burst }
  const colors = (spec.colors && spec.colors.length ? spec.colors : ['#ffffff']).map(hexToRgb)

  const room = MAX_PARTICLES - world.particles.length
  if (room <= 0) return
  const count = Math.min(spec.count, room)

  const height = Math.max(0, world.height - y)
  const delay = height * SOUND_DELAY_PER_PX

  if (type === 'text') {
    const made = spawnText(world, x, y, spec, colors, count)
    // 마스크가 없거나 비어 있으면 아무것도 안 만든다 — 소리만 나고 안 보이면 더 이상하다.
    if (made === 0) return
  } else {
    spawnDirectional(world, x, y, type, spec, colors, count)
  }

  world.sounds.push({
    type: 'burst',
    delay,
    volume: Math.min(1, 0.45 + count / 600),
    size: spec.speed / 320,
  })
  if (spec.crackle) {
    world.sounds.push({ type: 'crackle', delay: delay + 0.5, volume: 0.5, size: 1 })
  }
}

function spawnDirectional(world, x, y, type, spec, colors, count) {
  const dirs = directionsFor(type, count, world.rng)
  for (const d of dirs) {
    const speed = spec.speed * d.speed * range(world.rng, 0.9, 1.08)
    world.particles.push(createParticle({
      x, y,
      vx: d.x * speed,
      vy: d.y * speed,
      life: spec.life * range(world.rng, 0.82, 1.15),
      drag: spec.drag,
      gravity: GRAVITY,
      rgb: pick(world.rng, colors),
      size: spec.size * range(world.rng, 0.75, 1.25),
      twinkle: spec.twinkle,
      phase: range(world.rng, 0, 6.283),
    }))
  }
}

/**
 * 글자를 화면에 얼마나 크게 세울지. sampleMask 가 **가로 절반을 1 로** 정규화해 주므로,
 * 좌표에 곱할 배율 하나만 정하면 된다.
 *
 * - `spec.textHeight` — 글자 높이를 화면 높이의 몇 %로 (짧은 단어에 쓴다)
 * - `spec.width` — 글자 폭을 화면 폭의 몇 %로 (긴 문구에 쓴다)
 *
 * 높이로 정하는 길이 따로 있는 이유: 「I」와 「LOVE」를 같은 `width` 로 주면 획 하나짜리
 * I 가 LOVE 만큼 옆으로 벌어져 글자가 아니라 기둥이 된다. 이어지는 낱말들을 같은 크기로
 * 보이게 하려면 기준이 높이여야 한다.
 */
function textScale(world, mask, spec) {
  const aspect = mask.height / mask.width
  const half = spec.textHeight !== undefined
    ? (spec.textHeight * world.height) / (2 * aspect)
    : ((spec.width ?? 0.34) * world.width) / 2

  // 어떤 값을 줘도 화면 밖으로 나가지는 않게 한다. 글자가 잘리면 읽을 수가 없다.
  return Math.min(half, (0.88 * world.width) / 2)
}

/**
 * 글자.
 * @returns {number} 실제로 만든 파티클 수. 0 이면 마스크가 없거나 비었다는 뜻.
 */
function spawnText(world, x, y, spec, colors, count) {
  const mask = world.masks[spec.text]
  if (!mask) return 0

  const points = sampleMask(mask, count, world.rng)
  if (points.length === 0) return 0

  const halfWidth = textScale(world, mask, spec)

  for (const point of points) {
    const tx = x + point.x * halfWidth
    const ty = y + point.y * halfWidth
    world.particles.push(createParticle({
      x, y,
      vx: (tx - x) * TEXT_DRAG,
      vy: (ty - y) * TEXT_DRAG,
      life: spec.life * range(world.rng, 0.9, 1.1),
      drag: TEXT_DRAG,
      gravity: GRAVITY * 0.5,
      hold: TEXT_HOLD,
      holdGravity: TEXT_GRAVITY,
      rgb: pick(world.rng, colors),
      size: spec.size * range(world.rng, 0.8, 1.2),
      twinkle: 9,
      phase: range(world.rng, 0, 6.283),
    }))
  }
  return points.length
}

/** 렌더러가 소리를 가져간다. 두 번 재생되지 않도록 비우면서 준다. */
export function drainSounds(world) {
  const out = world.sounds
  world.sounds = []
  return out
}
