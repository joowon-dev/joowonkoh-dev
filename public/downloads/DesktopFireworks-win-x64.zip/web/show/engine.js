// 쇼의 월드. 각본을 시간순으로 소비해 포탄을 쏘고, 포탄이 터지면 파티클을 만들고,
// 소리 이벤트를 쌓아 둔다.
//
// 이 파일은 소리를 내지 않고 그림도 그리지 않는다 — `world.sounds` 에 이벤트를 쌓고,
// `world.particles` 를 들고 있을 뿐이다. 재생과 그리기는 렌더러의 일이다. 그래야
// 순수성이 유지되고, 같은 시드로 돌리면 언제나 같은 쇼가 나온다.

import {
  GRAVITY, BURST_DRAG, SHELL_DRAG, MAX_PARTICLES,
  TEXT_HOLD, TEXT_DRAG, TEXT_GRAVITY, SOUND_DELAY_PER_PX, LOOP_GAP,
} from './constants.js'
import { makeRng, range, pick } from './rng.js'
import { createParticle, stepParticle, isAlive } from './particles.js'
import { directionsFor, sampleMask, sampleImageMask } from './shapes.js'
import { createPads, stepPads, firePad, padAt } from './launcher.js'

/** '#ff5c8a' → [255, 92, 138]. 순수하게 두려고 DOM 색 파서를 쓰지 않는다. */
export function hexToRgb(hex) {
  const s = hex.replace('#', '')
  const full = s.length === 3 ? s[0] + s[0] + s[1] + s[1] + s[2] + s[2] : s
  const n = Number.parseInt(full, 16)
  if (!Number.isFinite(n)) return [255, 255, 255]
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255]
}

/**
 * 종류마다 다른 기본값. 각본이 값을 적으면 그게 이긴다.
 * 수양버들만 유난히 다르다 — 오래 살고 항력이 약해서 중력이 길게 늘어뜨린다.
 */
const BURST_DEFAULTS = {
  peony: { count: 150, speed: 300, life: 1.9, drag: BURST_DRAG, size: 1.9, twinkle: 0 },
  ring: { count: 130, speed: 320, life: 1.7, drag: BURST_DRAG, size: 1.8, twinkle: 0 },
  star: { count: 170, speed: 320, life: 1.8, drag: BURST_DRAG, size: 1.9, twinkle: 0 },
  heart: { count: 220, speed: 300, life: 2.3, drag: BURST_DRAG, size: 2.1, twinkle: 0 },
  willow: { count: 130, speed: 250, life: 3.4, drag: 0.42, size: 2.0, twinkle: 0 },
  text: { count: 420, speed: 0, life: TEXT_HOLD + 2.0, drag: TEXT_DRAG, size: 2.0, twinkle: 9 },
}

/**
 * 월드를 만든다.
 *
 * @param {object} options
 * @param {number} options.width @param {number} options.height 화면 크기(px)
 * @param {number} [options.seed] 같은 시드면 같은 쇼가 나온다
 * @param {object[]} options.script 각본 (script.js 참고)
 * @param {Record<string, {data: ArrayLike<number>, width: number, height: number}>} [options.masks]
 *   글자 문구 → 알파 마스크. 렌더러가 캔버스로 만들어 넣어 준다.
 */
export function createWorld({ width, height, seed = 20260906, script, masks = {} }) {
  return {
    width,
    height,
    seed,
    rng: makeRng(seed),
    script,
    masks,
    time: 0,
    /**
     * 시작부터 한 번도 안 되돌아가는 시계. `time` 은 각본이 한 바퀴 돌 때마다 0 으로
     * 돌아가므로 「몇 초 뒤에 쏘기」의 기준으로 쓸 수 없다.
     */
    clock: 0,
    /** 예약해 둔 발사. {at: clock 기준 시각, cue} — 카운트다운이 이걸 쓴다. */
    pending: [],
    cursor: 0,
    pads: createPads(width, height),
    shells: [],
    particles: [],
    /** 렌더러가 매 프레임 비워 간다. {type, delay, volume, size} */
    sounds: [],
    /** 각본을 한 바퀴 돈 횟수. 디버깅용. */
    loops: 0,
  }
}

/** 화면 크기가 바뀌었다 (모니터를 갈아 끼웠거나 해상도가 바뀌었거나). */
export function resizeWorld(world, width, height) {
  world.width = width
  world.height = height
  world.pads = createPads(width, height)
}

/** 각본을 처음부터 다시. 이미 떠 있는 불꽃은 그대로 두고 사그라들게 한다. */
export function restartWorld(world) {
  world.time = 0
  world.cursor = 0
  world.rng = makeRng(world.seed)
  // clock 과 pending 은 건드리지 않는다. 각본을 다시 시작한다고 예약해 둔 카운트다운이
  // 사라지면, 하필 그 사이에 각본이 한 바퀴 돈 사람만 이미지를 못 보게 된다.
}

/**
 * 각본을 갈아 끼운다 (쇼 템플릿을 바꿀 때). 마스크도 같이 바꾼다 — 템플릿마다 쓰는
 * 문구가 다르고, 마스크는 렌더러가 캔버스로 만들어 넣어 주기 때문이다.
 *
 * 떠 있는 불꽃은 지우지 않는다. 바꾼 순간 화면이 텅 비는 것보다 사그라드는 편이 낫다.
 */
export function setShow(world, script, masks = {}) {
  world.script = script
  world.masks = masks
  restartWorld(world)
}

/**
 * 각본과 **무관하게** 지금 포탄 하나를 올린다. 이미지 불꽃이 이 길로 간다.
 *
 * `world.time` 도 `world.cursor` 도 건드리지 않는다 — 돌던 쇼는 그대로 흘러가고,
 * 이 한 발만 그 위에 얹힌다.
 */
export function launchNow(world, cue, delay = 0) {
  if (delay > 0) world.pending.push({ at: world.clock + delay, cue })
  else launch(world, cue)
}

/** 예약해 둔 것 중 시각이 된 것을 쏜다. */
function firePending(world) {
  if (world.pending.length === 0) return
  const waiting = []
  for (const item of world.pending) {
    if (item.at <= world.clock) launch(world, item.cue)
    else waiting.push(item)
  }
  world.pending = waiting
}

/** 각본의 마지막 큐 시각. 여기서 LOOP_GAP 만큼 더 지나면 다시 돈다. */
function scriptEnd(script) {
  let end = 0
  for (const cue of script) if (cue.at > end) end = cue.at
  return end
}

/**
 * 한 스텝. 반드시 고정 dt 로 부른다 — 프레임 시간을 그대로 넣으면 기계마다 결과가
 * 달라진다.
 */
export function stepWorld(world, dt) {
  world.time += dt
  world.clock += dt

  fireDueCues(world)
  firePending(world)
  stepShells(world, dt)
  stepParticles(world, dt)
  stepPads(world.pads, dt)

  if (world.time > scriptEnd(world.script) + LOOP_GAP) {
    world.loops += 1
    restartWorld(world)
  }
}

/** 시각이 된 큐를 전부 쏜다. 각본은 시간순이라고 본다. */
function fireDueCues(world) {
  while (world.cursor < world.script.length && world.script[world.cursor].at <= world.time) {
    launch(world, world.script[world.cursor])
    world.cursor += 1
  }
}

/**
 * 포탄 하나를 쏜다.
 *
 * 각본은 「화면 높이의 몇 %까지 올라가나」(`height`)만 적는다. 초기 속도와 도화선 시간은
 * 거기서 풀린다: `v0 = sqrt(2·g·h)`, 꼭대기까지 `t = v0/g`. 가로 목표(`x`)가 있으면
 * 그 시간 안에 도달하도록 가로 속도를 정한다 — 중력이 가로에 영향을 주지 않으니
 * 그냥 나누면 된다.
 */
function launch(world, cue) {
  const pad = padAt(world.pads, cue.pad ?? 0)
  if (!pad) return
  firePad(pad)

  const rise = Math.max(40, (cue.height ?? 0.55) * world.height)
  const vy = -Math.sqrt(2 * GRAVITY * rise)
  const fuse = -vy / GRAVITY

  // 가로 목표. 안 적으면 발사대가 겨누는 쪽으로 살짝 흘러간다.
  const targetX = cue.x === undefined
    ? pad.x + Math.tan(pad.tilt) * rise
    : cue.x * world.width
  const vx = (targetX - pad.x) / fuse

  const rgb = hexToRgb(cue.trail ?? '#ffd9a0')
  const shell = createParticle({
    x: pad.x, y: pad.muzzleY, vx, vy,
    life: fuse, drag: SHELL_DRAG, gravity: GRAVITY,
    rgb, size: 2.2, twinkle: 26, phase: range(world.rng, 0, 6.283),
  })

  world.shells.push({ p: shell, burst: cue.burst ?? { type: 'peony' } })
  world.sounds.push({ type: 'launch', delay: 0, volume: 0.5, size: 0 })
}

function stepShells(world, dt) {
  const list = world.shells
  let keep = 0
  for (let i = 0; i < list.length; i += 1) {
    const shell = list[i]
    stepParticle(shell.p, dt)
    if (isAlive(shell.p)) {
      list[keep] = shell
      keep += 1
    } else {
      // 여기서 world.particles 가 늘어난다. shells 는 따로 도는 배열이라 안전하다.
      explode(world, shell.p.x, shell.p.y, shell.burst)
    }
  }
  list.length = keep
}

/**
 * 살아 있는 것만 **제자리에서** 앞으로 당긴다.
 *
 * 새 배열을 만들어 담으면 파티클 18000 개짜리 배열을 프레임마다 두 개씩(120Hz 라 프레임
 * 하나에 두 스텝) 새로 할당하게 된다. 그 쓰레기를 치우느라 프레임이 튄다.
 */
function stepParticles(world, dt) {
  const list = world.particles
  let keep = 0
  for (let i = 0; i < list.length; i += 1) {
    const p = list[i]
    stepParticle(p, dt)
    // 화면 아래로 완전히 빠진 파티클은 더 볼 일이 없다.
    if (isAlive(p) && p.y < world.height + 60) {
      list[keep] = p
      keep += 1
    }
  }
  list.length = keep
}

/**
 * 터진다. 두 가지 방식이 있다.
 *
 * **방향 방식** (하트·별·고리·국화·수양버들) — 모양이 주는 단위 벡터에 속도를 곱해
 * 그대로 쏜다. 그 뒤는 중력과 항력에 맡긴다.
 *
 * **목표 방식** (글자) — 지수 항력에서 총 이동거리가 `v0/drag` 로 수렴하는 성질을
 * 거꾸로 쓴다. 목표점까지의 변위에 항력 계수를 곱한 속도를 주면 파티클이 정확히 그
 * 자리에 가서 선다. 반복도 보정도 없다.
 */
export function explode(world, x, y, burst) {
  const type = burst.type ?? 'peony'
  const spec = { ...(BURST_DEFAULTS[type] ?? BURST_DEFAULTS.peony), ...burst }
  const colors = (spec.colors && spec.colors.length ? spec.colors : ['#ffffff']).map(hexToRgb)

  const room = MAX_PARTICLES - world.particles.length
  if (room <= 0) return
  const count = Math.min(spec.count, room)

  const height = Math.max(0, world.height - y)
  const delay = height * SOUND_DELAY_PER_PX

  if (type === 'text') {
    const made = spawnText(world, x, y, spec, colors, count)
    // 마스크가 없거나 비어 있으면 아무것도 안 만든다 — 소리만 나고 안 보이면 더 이상하다.
    if (made === 0) return
  } else {
    spawnDirectional(world, x, y, type, spec, colors, count)
  }

  world.sounds.push({
    type: 'burst',
    delay,
    volume: Math.min(1, 0.45 + count / 600),
    size: spec.speed / 320,
  })
  if (spec.crackle) {
    world.sounds.push({ type: 'crackle', delay: delay + 0.5, volume: 0.5, size: 1 })
  }
}

function spawnDirectional(world, x, y, type, spec, colors, count) {
  const dirs = directionsFor(type, count, world.rng)
  for (const d of dirs) {
    const speed = spec.speed * d.speed * range(world.rng, 0.9, 1.08)
    world.particles.push(createParticle({
      x, y,
      vx: d.x * speed,
      vy: d.y * speed,
      life: spec.life * range(world.rng, 0.82, 1.15),
      drag: spec.drag,
      gravity: GRAVITY,
      rgb: pick(world.rng, colors),
      size: spec.size * range(world.rng, 0.75, 1.25),
      twinkle: spec.twinkle,
      // 이미지는 꼬리를 안 끈다. 점 하나가 그림의 한 점이라 꼬리가 그림을 번지게 한다.
      streak: spec.streak !== false,
      phase: range(world.rng, 0, 6.283),
    }))
  }
}

/**
 * 글자를 화면에 얼마나 크게 세울지. sampleMask 가 **가로 절반을 1 로** 정규화해 주므로,
 * 좌표에 곱할 배율 하나만 정하면 된다.
 *
 * - `spec.textHeight` — 글자 높이를 화면 높이의 몇 %로 (짧은 단어에 쓴다)
 * - `spec.width` — 글자 폭을 화면 폭의 몇 %로 (긴 문구에 쓴다)
 *
 * 높이로 정하는 길이 따로 있는 이유: 「I」와 「LOVE」를 같은 `width` 로 주면 획 하나짜리
 * I 가 LOVE 만큼 옆으로 벌어져 글자가 아니라 기둥이 된다. 이어지는 낱말들을 같은 크기로
 * 보이게 하려면 기준이 높이여야 한다.
 */
function textScale(world, mask, spec) {
  const aspect = mask.height / mask.width

  // `fit` — 가로세로 비율을 **미리 모르는** 것(이미지)을 화면 안에 통째로 넣는다.
  // 글자는 어떤 모양인지 각본을 쓰는 사람이 알기 때문에 높이든 폭이든 골라 줄 수 있지만,
  // 이미지는 무엇이 올지 모른다 — 한쪽만 맞추면 다른 쪽이 화면 밖으로 나간다.
  // 그래서 가로와 세로 중 **더 빡빡한 쪽**을 따른다.
  if (spec.fit !== undefined) {
    const byWidth = (spec.fit * world.width) / 2
    const byHeight = (spec.fit * world.height) / (2 * aspect)
    return Math.min(byWidth, byHeight)
  }

  const half = spec.textHeight !== undefined
    ? (spec.textHeight * world.height) / (2 * aspect)
    : ((spec.width ?? 0.34) * world.width) / 2

  // 어떤 값을 줘도 화면 밖으로 나가지는 않게 한다. 글자가 잘리면 읽을 수가 없다.
  return Math.min(half, (0.88 * world.width) / 2)
}

/**
 * 글자.
 * @returns {number} 실제로 만든 파티클 수. 0 이면 마스크가 없거나 비었다는 뜻.
 */
function spawnText(world, x, y, spec, colors, count) {
  // 글자는 `text` 가 곧 마스크 키다. 이미지는 문구가 없어서 `mask` 로 키를 따로 적는다.
  const mask = world.masks[spec.mask ?? spec.text]
  if (!mask) return 0

  // 색이 있는 마스크(이미지)는 **정사각 격자로** 뽑는다. sampleMask 의 「목록을 일정
  // 간격으로 건너뛰기」는 간격이 가로에만 먹어서 그림을 가로로 눌러 버리고 대각선
  // 간섭무늬를 깐다 — 획이 굵은 글자는 견디지만 그림은 형체가 갈려 없어진다.
  let points = mask.rgb
    ? sampleImageMask(mask, count, world.rng)
    : sampleMask(mask, count, world.rng)
  if (points.length === 0) return 0

  // 미리 뽑아 둔 점은 `count` 를 모른다. 자리가 모자라면(이미 떠 있는 것이 많으면)
  // 여기서 솎아 낸다. 앞에서부터 자르면 격자의 윗줄만 남아 그림의 절반이 사라지므로
  // 일정 간격으로 건너뛰며 고르게 솎는다.
  if (points.length > count) {
    const stride = points.length / count
    const thinned = new Array(count)
    for (let i = 0; i < count; i += 1) thinned[i] = points[Math.floor(i * stride)]
    points = thinned
  }

  const halfWidth = textScale(world, mask, spec)

  for (const point of points) {
    const tx = x + point.x * halfWidth
    const ty = y + point.y * halfWidth
    world.particles.push(createParticle({
      x, y,
      vx: (tx - x) * TEXT_DRAG,
      vy: (ty - y) * TEXT_DRAG,
      life: spec.life * range(world.rng, 0.9, 1.1),
      drag: TEXT_DRAG,
      gravity: GRAVITY * 0.5,
      // 이미지는 오래 세워 둔다. 글자는 읽는 데 1.9 초면 되지만 그림은 뜯어보게 된다.
      hold: spec.hold ?? TEXT_HOLD,
      holdGravity: TEXT_GRAVITY,
      // 마스크가 색을 들고 있으면(이미지) 그 색으로, 아니면(글자) 팔레트에서 뽑아서.
      rgb: point.rgb ?? pick(world.rng, colors),
      size: spec.size * range(world.rng, 0.8, 1.2),
      // 반짝임은 점마다 밝기를 무작위로 깎는다. 글자는 그래야 살아 있어 보이지만
      // 이미지는 **밝기가 곧 그림**이라, 흔들면 명암이 뭉개진다.
      twinkle: spec.twinkle,
      // 이미지는 꼬리를 안 끈다. 점 하나가 그림의 한 점이라 꼬리가 그림을 번지게 한다.
      streak: spec.streak !== false,
      phase: range(world.rng, 0, 6.283),
    }))
  }
  return points.length
}

/** 렌더러가 소리를 가져간다. 두 번 재생되지 않도록 비우면서 준다. */
export function drainSounds(world) {
  const out = world.sounds
  world.sounds = []
  return out
}
