// 터짐의 모양. 전부 순수 함수다.
//
// 모든 함수는 **화면 좌표계**(y 가 아래쪽)의 벡터 배열을 준다. 크기는 대체로 1 이하로
// 맞춰 두었고, 엔진이 여기에 속도(방향 방식)나 반지름(목표 방식)을 곱한다.
//
// `speed` 는 방향마다 다른 세기다. 국화처럼 안쪽까지 채우는 불꽃은 이 값이 0~1 로
// 흩어지고, 고리처럼 테두리만 있는 불꽃은 전부 1 에 가깝다.

import { range } from './rng.js'

/**
 * @typedef {{ x: number, y: number, speed: number }} Direction
 */

/**
 * 국화 — 가장 흔한 둥근 불꽃. 3차원 구면에 고르게 뿌린 뒤 화면에 그대로 눌러 담는다.
 * 평면에서 각도만 고르게 뽑으면 가운데가 비어 보이는데, 구면을 눌러 담으면 테두리가
 * 진하고 가운데가 옅은 실제 불꽃의 밀도가 그냥 나온다.
 */
export function peonyDirections(count, rng) {
  const out = []
  for (let i = 0; i < count; i += 1) {
    // 구면 위 균등 분포: z 를 [-1,1] 균등하게 뽑는다.
    const z = range(rng, -1, 1)
    const r = Math.sqrt(1 - z * z)
    const a = range(rng, 0, Math.PI * 2)
    out.push({ x: r * Math.cos(a), y: r * Math.sin(a), speed: range(rng, 0.75, 1) })
  }
  return out
}

/** 고리 — 테두리만. 살짝 흔들어야 자로 그린 원처럼 안 보인다. */
export function ringDirections(count, rng) {
  const out = []
  for (let i = 0; i < count; i += 1) {
    const a = (i / count) * Math.PI * 2 + range(rng, -0.02, 0.02)
    out.push({ x: Math.cos(a), y: Math.sin(a), speed: range(rng, 0.94, 1) })
  }
  return out
}

/**
 * 하트. 고전적인 매개변수 곡선을 쓴다.
 *   x = 16 sin³t,  y = 13 cos t − 5 cos 2t − 2 cos 3t − cos 4t
 * 이 곡선은 원점이 가운데가 아니다 — y 가 −17 … +11.92 라 가운데가 −2.538 이다.
 * 그만큼 밀어 올려야 하트가 화면에서 위아래로 치우치지 않는다.
 * 화면 좌표라 y 를 뒤집는다 — 뒤집지 않으면 뾰족한 끝이 위로 간다.
 */
export function heartDirections(count, rng) {
  const out = []
  const shift = 2.538 // 곡선 y 범위의 가운데. 이만큼 더해야 0 이 하트의 중심이 된다
  const scale = 1 / 16
  for (let i = 0; i < count; i += 1) {
    const t = (i / count) * Math.PI * 2
    const mx = 16 * Math.sin(t) ** 3
    const my = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)
    // 테두리에서 살짝 안쪽으로도 흩뿌려 속을 채운다. 완전히 빈 하트는 멀리서 안 읽힌다.
    const fill = range(rng, 0.82, 1)
    out.push({
      x: mx * scale * fill,
      y: -(my + shift) * scale * fill,
      speed: range(rng, 0.95, 1),
    })
  }
  return out
}

/** 별 — 꼭짓점 5 개의 별 모양 테두리. */
export function starDirections(count, rng, points = 5) {
  const out = []
  const inner = 0.42
  for (let i = 0; i < count; i += 1) {
    const t = (i / count) * points // 0..points, 한 칸이 꼭짓점 하나
    const seg = Math.floor(t)
    const f = t - seg
    // 꼭짓점 → 안쪽 → 다음 꼭짓점으로 직선으로 간다.
    const a0 = (seg / points) * Math.PI * 2 - Math.PI / 2
    const a1 = ((seg + 0.5) / points) * Math.PI * 2 - Math.PI / 2
    const a2 = ((seg + 1) / points) * Math.PI * 2 - Math.PI / 2
    const p0 = [Math.cos(a0), Math.sin(a0)]
    const p1 = [Math.cos(a1) * inner, Math.sin(a1) * inner]
    const p2 = [Math.cos(a2), Math.sin(a2)]
    const [ax, ay] = f < 0.5 ? p0 : p1
    const [bx, by] = f < 0.5 ? p1 : p2
    const g = f < 0.5 ? f * 2 : (f - 0.5) * 2
    const fill = range(rng, 0.86, 1)
    out.push({ x: (ax + (bx - ax) * g) * fill, y: (ay + (by - ay) * g) * fill, speed: 1 })
  }
  return out
}

/**
 * 수양버들 — 위로 퍼졌다가 길게 늘어져 떨어지는 불꽃. 방향을 위쪽으로 치우치게 주고,
 * 엔진이 이 종류에 긴 수명과 약한 항력을 준다. 늘어지는 모양은 중력이 만든다.
 */
export function willowDirections(count, rng) {
  const out = []
  for (let i = 0; i < count; i += 1) {
    const a = range(rng, 0, Math.PI * 2)
    const up = range(rng, 0.15, 1)
    out.push({ x: Math.cos(a) * up, y: Math.sin(a) * up * 0.55 - 0.35, speed: range(rng, 0.6, 1) })
  }
  return out
}

/** 모양 이름 → 방향 함수. 각본이 문자열로 부르므로 여기 없는 이름은 국화로 떨어진다. */
const BY_NAME = {
  peony: peonyDirections,
  ring: ringDirections,
  heart: heartDirections,
  star: starDirections,
  willow: willowDirections,
}

/**
 * 각본이 준 모양 이름으로 방향을 만든다.
 * @returns {Direction[]}
 */
export function directionsFor(type, count, rng) {
  return (BY_NAME[type] ?? peonyDirections)(count, rng)
}

/**
 * 글자 마스크에서 목표점을 뽑는다.
 *
 * 마스크는 렌더러가 오프스크린 캔버스에 문구를 그려서 만든다 — 캔버스가 필요한 일이라
 * 여기(순수 모듈)에서는 하지 않고, 이미 만들어진 알파 배열만 받는다. 그래서 이 함수는
 * 테스트가 돌고, 한글이든 이모지든 폰트가 그릴 수 있으면 그대로 된다.
 *
 * 좌표는 **가로 절반을 1 로 놓고** 정규화한다(가로세로 비율 유지). 그래서 엔진은
 * 「글자를 화면 폭의 몇 %로 세울지」만 정하면 된다.
 *
 * @param {{data: ArrayLike<number>, width: number, height: number}} mask 알파 0~255
 * @param {number} count 뽑을 점의 수
 * @param {() => number} rng
 * @param {number} threshold 이보다 진한 픽셀만 글자로 본다
 * @returns {{x: number, y: number}[]} 빈 마스크면 빈 배열
 */
export function sampleMask(mask, count, rng, threshold = 128) {
  const { data, width, height } = mask
  const lit = []
  for (let i = 0; i < width * height; i += 1) {
    if (data[i] >= threshold) lit.push(i)
  }
  if (lit.length === 0 || count <= 0) return []

  const halfW = width / 2
  const halfH = height / 2
  const out = []
  // 고르게 훑는다 — 난수로 뽑으면 같은 픽셀이 겹쳐 글자에 구멍이 난다.
  for (let i = 0; i < count; i += 1) {
    const index = lit[Math.floor((i / count) * lit.length)]
    const px = index % width
    const py = Math.floor(index / width)
    // 픽셀 안에서 조금 흔들어야 격자 무늬가 안 보인다.
    out.push({
      x: (px + range(rng, 0, 1) - halfW) / halfW,
      y: (py + range(rng, 0, 1) - halfH) / halfW,
    })
  }
  return out
}
