// 파티클 하나의 물리. 순수 — window·Date.now·Math.random 을 쓰지 않는다.
//
// 궤적(trail)은 배경을 칠해서 만드는 잔상이 아니라 **파티클이 직접 들고 다니는 지난
// 위치들**이다. 이 앱은 바탕화면을 가리면 안 되므로 캔버스를 매 프레임 완전히 지우고,
// 잔상은 이 위치들을 선분으로 이어 그려서 만든다. 자세한 사정은 설계 문서에 있다.

import { GRAVITY, TRAIL_LENGTH, TRAIL_EVERY } from './constants.js'

/**
 * @typedef {object} Particle
 * @property {number} x @property {number} y
 * @property {number} vx @property {number} vy
 * @property {number} age 태어난 뒤 흐른 시간
 * @property {number} life 이 시간이 지나면 죽는다
 * @property {number} drag 지수 항력 계수
 * @property {number} gravity 지금 받는 중력
 * @property {number} holdGravity hold 가 남아 있는 동안 대신 쓰는 중력
 * @property {number} hold 이 시간 동안은 holdGravity 를 쓴다 (글자 불꽃이 서 있는 동안)
 * @property {number[]} rgb 0~255
 * @property {number} size 반지름
 * @property {number} twinkle 0 이면 안 반짝, 크면 빨리 반짝
 * @property {number} phase 반짝임 위상 — 파티클마다 달라야 한꺼번에 안 깜빡인다
 * @property {number[]} trail 링 버퍼 [x0,y0,x1,y1,...] 길이 TRAIL_LENGTH*2
 * @property {number} head 가장 최근에 쓴 칸
 * @property {number} tick 궤적을 몇 스텝 만에 한 번 남길지 세는 값
 */

/**
 * 파티클 하나를 만든다. 빠진 값은 「평범한 잔불」 기본값으로 채운다.
 * @returns {Particle}
 */
export function createParticle(options) {
  const {
    x, y, vx = 0, vy = 0,
    life = 1.6, drag = 1.15, gravity = GRAVITY,
    hold = 0, holdGravity = 0,
    rgb = [255, 255, 255], size = 1.6,
    twinkle = 0, phase = 0,
  } = options

  const trail = new Array(TRAIL_LENGTH * 2)
  for (let i = 0; i < TRAIL_LENGTH; i += 1) {
    trail[i * 2] = x
    trail[i * 2 + 1] = y
  }

  return {
    x, y, vx, vy, age: 0, life, drag, gravity, hold, holdGravity,
    rgb, size, twinkle, phase, trail, head: 0, tick: 0,
  }
}

/**
 * 한 스텝. 중력 → 항력 → 이동 순서다.
 *
 * 항력은 지수 감쇠 `v *= exp(-drag*dt)` 다. 프레임률과 무관하게 같은 결과가 나오고,
 * 초기 속도 v0 인 파티클이 멈출 때까지 나아가는 거리가 정확히 `v0/drag` 로 수렴한다 —
 * 글자 불꽃이 원하는 자리에 서게 만드는 근거가 이 성질이다.
 *
 * @param {Particle} p
 * @param {number} dt
 */
export function stepParticle(p, dt) {
  if (p.hold > 0) {
    p.hold -= dt
    p.vy += p.holdGravity * dt
  } else {
    p.vy += p.gravity * dt
  }

  const damp = Math.exp(-p.drag * dt)
  p.vx *= damp
  p.vy *= damp

  p.x += p.vx * dt
  p.y += p.vy * dt
  p.age += dt

  p.tick += 1
  if (p.tick >= TRAIL_EVERY) {
    p.tick = 0
    p.head = (p.head + 1) % TRAIL_LENGTH
    p.trail[p.head * 2] = p.x
    p.trail[p.head * 2 + 1] = p.y
  }
}

/** 아직 살아 있나. */
export function isAlive(p) {
  return p.age < p.life
}

/**
 * 지금 밝기 0~1. 수명 끝에서 0 으로 사그라들고, twinkle 이 있으면 그 위에 반짝임이 얹힌다.
 * 반짝임은 밝기를 **더하지 않는다** — 곱해서 깎기만 한다. 안 그러면 사그라들다 말고
 * 다시 밝아지는 파티클이 생겨 꺼지는 느낌이 사라진다.
 */
export function brightness(p) {
  const t = p.age / p.life
  if (t >= 1) return 0
  const fade = 1 - t * t // 끝에서 급히 꺼지지 않고 부드럽게
  if (p.twinkle <= 0) return fade
  const flicker = 0.55 + 0.45 * Math.sin(p.age * p.twinkle + p.phase)
  return fade * flicker
}

/**
 * 궤적 점을 오래된 것부터 순서대로 준다. 그리는 쪽이 링 버퍼를 몰라도 되게 한다.
 * @param {Particle} p
 * @returns {number[]} [x_oldest, y_oldest, ..., x_newest, y_newest]
 */
export function trailPoints(p) {
  const out = new Array(TRAIL_LENGTH * 2)
  for (let i = 0; i < TRAIL_LENGTH; i += 1) {
    const slot = (p.head + 1 + i) % TRAIL_LENGTH
    out[i * 2] = p.trail[slot * 2]
    out[i * 2 + 1] = p.trail[slot * 2 + 1]
  }
  return out
}

/**
 * 지수 항력만 받는 파티클이 결국 얼마나 나아가는지. `v0 / drag`.
 * 글자 불꽃이 이 식을 거꾸로 써서 초기 속도를 정한다.
 */
export function driftDistance(speed, drag) {
  return speed / drag
}

/** 목표점까지 정확히 나아가게 하는 초기 속도. driftDistance 의 역함수다. */
export function speedToReach(distance, drag) {
  return distance * drag
}
