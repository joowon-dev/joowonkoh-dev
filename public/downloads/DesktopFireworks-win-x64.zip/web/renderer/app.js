// 렌더러. 캔버스를 잡고, 글자 마스크를 만들고, 고정 타임스텝으로 월드를 돌리고,
// 그리고, 소리를 낸다. 셸(맥/윈도우)이 주는 window.sneaky 로 핫키를 받는다.

import { DT } from '../show/constants.js'
import { createWorld, stepWorld, resizeWorld, restartWorld, drainSounds } from '../show/engine.js'
import { SHOW, collectTexts } from '../show/script.js'
import { draw } from '../render/draw.js'
import { createAudio } from './audio.js'

const canvas = document.getElementById('stage')
const ctx = canvas.getContext('2d', { alpha: true })

/** 안내를 몇 초 띄우고 몇 초에 걸쳐 지울지. */
const HINT_SHOW = 6
const HINT_FADE = 1.5

/**
 * 글자를 픽셀로 바꾼다. 캔버스가 필요한 일이라 순수 모듈이 아니라 여기서 한다.
 *
 * 굵은 글씨로 크게 그린 다음 알파 채널만 뽑아 낸다. 한글·이모지 모두, 폰트가 그릴 수
 * 있으면 그대로 마스크가 된다.
 *
 * @returns {{data: Uint8Array, width: number, height: number}}
 */
function buildMask(text, fontSize = 180) {
  // 로마자는 세리프로, 한글은 고딕으로 뽑는다. 폰트 대체는 **글자 단위**로 일어나므로
  // 앞에 세리프를 두면 「I LOVE YOU」만 세리프가 되고 「사랑해」는 뒤의 고딕이 그린다.
  //
  // 세리프여야 하는 이유는 대문자 I 하나 때문이다. 산세리프의 I 는 획이 하나뿐이라
  // 불꽃으로 세우면 글자가 아니라 그냥 막대기로 보인다 — 가로획이 있어야 I 로 읽힌다.
  const family = 'Georgia, "Times New Roman", "Apple SD Gothic Neo", "Malgun Gothic", serif'
  const font = `800 ${fontSize}px ${family}`

  // 폭을 재려면 컨텍스트가 하나 있어야 하고, 캔버스 크기를 바꾸면 컨텍스트 상태가
  // 초기화되므로 잰 다음 다시 폰트를 넣는다.
  const measure = document.createElement('canvas').getContext('2d')
  measure.font = font
  const width = Math.max(8, Math.ceil(measure.measureText(text).width) + fontSize * 0.3)
  const height = Math.ceil(fontSize * 1.35)

  const off = document.createElement('canvas')
  off.width = width
  off.height = height
  const octx = off.getContext('2d')
  octx.font = font
  octx.textAlign = 'center'
  octx.textBaseline = 'middle'
  octx.fillStyle = '#fff'
  octx.fillText(text, width / 2, height / 2)

  const pixels = octx.getImageData(0, 0, width, height).data
  const data = new Uint8Array(width * height)
  for (let i = 0; i < data.length; i += 1) data[i] = pixels[i * 4 + 3]

  return crop({ data, width, height })
}

/**
 * 글자가 실제로 칠해진 만큼만 남긴다.
 *
 * 자르지 않으면 마스크의 크기가 글자가 아니라 **캔버스의 여백**에 좌우된다 — 「I」처럼
 * 좁은 글자는 여백이 대부분이라, 크기를 어떻게 주든 엉뚱한 비율로 선다. 잘라 두면
 * 마스크의 가로세로가 곧 글자의 가로세로가 되어, 엔진이 「이 높이로 세워라」를 지킬 수 있다.
 */
function crop(mask, threshold = 128) {
  const { data, width, height } = mask
  let minX = width, minY = height, maxX = -1, maxY = -1
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      if (data[y * width + x] < threshold) continue
      if (x < minX) minX = x
      if (x > maxX) maxX = x
      if (y < minY) minY = y
      if (y > maxY) maxY = y
    }
  }
  // 빈 마스크(공백만 있는 문구 등)는 그대로 돌려준다 — 엔진이 알아서 건너뛴다.
  if (maxX < 0) return mask

  const w = maxX - minX + 1
  const h = maxY - minY + 1
  const out = new Uint8Array(w * h)
  for (let y = 0; y < h; y += 1) {
    for (let x = 0; x < w; x += 1) out[y * w + x] = data[(y + minY) * width + x + minX]
  }
  return { data: out, width: w, height: h }
}

function buildMasks(texts) {
  const masks = {}
  for (const text of texts) {
    try {
      masks[text] = buildMask(text)
    } catch (error) {
      // 마스크를 못 만들어도 쇼는 계속돼야 한다 — 그 큐만 조용히 건너뛴다.
      console.error(`글자 마스크 실패: ${text} — ${error}`)
    }
  }
  return masks
}

/** 캔버스를 화면 크기에 맞춘다. 레티나에서는 실제 픽셀이 두 배다. */
function fit(world) {
  const dpr = Math.min(window.devicePixelRatio || 1, 2)
  const width = Math.max(1, Math.round(window.innerWidth))
  const height = Math.max(1, Math.round(window.innerHeight))
  canvas.width = Math.round(width * dpr)
  canvas.height = Math.round(height * dpr)
  canvas.style.width = `${width}px`
  canvas.style.height = `${height}px`
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
  if (world) resizeWorld(world, width, height)
  return { width, height, dpr }
}

const size = fit(null)
const world = createWorld({
  width: size.width,
  height: size.height,
  script: SHOW,
  masks: buildMasks(collectTexts(SHOW)),
})

const audio = createAudio()

// ── 셸이 주는 다리. 브라우저로 열면 없고, 없어도 쇼는 그냥 돈다.
const bridge = window.sneaky
let hint = bridge?.keyHint ?? '⌥⇧F 다시 보기 · ⌥⇧H 숨기기'

// 셸이 기억해 둔 소리 크기가 있으면 그걸로 시작한다.
if (audio && typeof bridge?.volume === 'number') audio.setVolume(bridge.volume)
bridge?.onVolume?.((value) => audio?.setVolume(value))
bridge?.onRestart?.(() => {
  restartWorld(world)
  hintTime = 0
})
bridge?.onHint?.((text) => {
  hint = text
  hintTime = 0
})

// 브라우저로 열어 볼 때를 위한 임시 조작. 셸에서는 핫키가 이 자리를 대신한다.
window.addEventListener('keydown', (event) => {
  if (event.key === 'r' || event.key === 'R') {
    restartWorld(world)
    hintTime = 0
  }
})

// 웹뷰가 소리를 막고 있으면 첫 상호작용에서 깨운다. 셸에서는 애초에 막지 않게 해 두었다.
window.addEventListener('pointerdown', () => audio?.resume(), { once: true })

let hintTime = 0
let accumulator = 0
let last = performance.now() / 1000

function frame(now) {
  const seconds = now / 1000
  let elapsed = seconds - last
  last = seconds

  // 창이 가려졌다 돌아오면 elapsed 가 몇 초씩 된다. 그대로 넣으면 그 시간만큼 쇼를
  // 몰아서 돌리느라 한 프레임이 멈춘다 — 잘라 낸다.
  if (elapsed > 0.25) elapsed = 0.25

  accumulator += elapsed
  hintTime += elapsed

  while (accumulator >= DT) {
    stepWorld(world, DT)
    accumulator -= DT
  }

  if (audio) audio.play(drainSounds(world))
  else drainSounds(world)

  const hintAlpha = hintTime < HINT_SHOW
    ? 1
    : Math.max(0, 1 - (hintTime - HINT_SHOW) / HINT_FADE)
  draw(ctx, world, { hint, hintAlpha })

  requestAnimationFrame(frame)
}

window.addEventListener('resize', () => fit(world))
requestAnimationFrame(frame)

/**
 * 확인용 손잡이. 쇼의 어느 지점이 어떻게 보이는지 눈으로 볼 때 쓴다 —
 * 하트가 하트로 보이는지, 글자가 읽히는지는 테스트로 알 수 없고 봐야만 안다.
 * 브라우저 콘솔에서 `__fw.seek(34)` 처럼 부른다.
 */
window.__fw = {
  world,
  seek(seconds) {
    restartWorld(world)
    world.particles = []
    world.shells = []
    const count = Math.round(seconds / DT)
    for (let i = 0; i < count; i += 1) stepWorld(world, DT)
    drainSounds(world) // 몰아서 돌린 만큼의 소리가 한꺼번에 터지지 않게 버린다
  },
}
