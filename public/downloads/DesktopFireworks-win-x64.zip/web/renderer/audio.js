// 소리. 음원 파일은 하나도 없다 — 전부 WebAudio 로 만든다.
//
// 엔진은 소리를 내지 않고 「무엇이 언제 났는지」만 쌓아 둔다(engine.js 의 world.sounds).
// 여기가 그걸 받아서 실제로 재생한다. 순수 모듈이 소리를 모르는 이유이자, 테스트가
// 오디오 장치 없이 도는 이유다.

/** 잡음 버퍼. 매번 만들면 비싸서 한 번만 만들어 돌려 쓴다. */
function makeNoise(ctx, seconds = 2) {
  const buffer = ctx.createBuffer(1, Math.floor(ctx.sampleRate * seconds), ctx.sampleRate)
  const data = buffer.getChannelData(0)
  // 여기서는 Math.random 을 써도 된다 — 소리의 잡음이라 결정론을 지킬 이유가 없고,
  // 순수 모듈 바깥이다.
  for (let i = 0; i < data.length; i += 1) data[i] = Math.random() * 2 - 1
  return buffer
}

export function createAudio() {
  const Ctor = window.AudioContext || window.webkitAudioContext
  if (!Ctor) return null

  const ctx = new Ctor()
  const master = ctx.createGain()
  master.gain.value = 0.55
  master.connect(ctx.destination)
  const noise = makeNoise(ctx)

  function noiseSource(when, duration, rate = 1) {
    const src = ctx.createBufferSource()
    src.buffer = noise
    src.loop = true
    src.playbackRate.value = rate
    src.start(when)
    src.stop(when + duration)
    return src
  }

  /** 발사 「슉」 — 좁은 대역의 잡음이 위로 훑고 올라간다. */
  function launch(when, volume) {
    const duration = 0.42
    const src = noiseSource(when, duration)
    const band = ctx.createBiquadFilter()
    band.type = 'bandpass'
    band.Q.value = 5
    band.frequency.setValueAtTime(320, when)
    band.frequency.exponentialRampToValueAtTime(1900, when + duration)

    const gain = ctx.createGain()
    gain.gain.setValueAtTime(0.0001, when)
    gain.gain.exponentialRampToValueAtTime(0.09 * volume, when + 0.06)
    gain.gain.exponentialRampToValueAtTime(0.0001, when + duration)

    src.connect(band).connect(gain).connect(master)
  }

  /**
   * 터짐 「펑」 — 두 겹이다. 저역 잡음이 몸통을, 사인파 한 번이 배를 때리는 저음을 낸다.
   * size 가 크면 낮고 길게 울린다.
   */
  function burst(when, volume, size) {
    const duration = 0.55 + size * 0.5
    const src = noiseSource(when, duration, 0.7)
    const low = ctx.createBiquadFilter()
    low.type = 'lowpass'
    low.frequency.setValueAtTime(1400, when)
    low.frequency.exponentialRampToValueAtTime(180, when + duration)

    const gain = ctx.createGain()
    gain.gain.setValueAtTime(0.0001, when)
    gain.gain.exponentialRampToValueAtTime(0.5 * volume, when + 0.012)
    gain.gain.exponentialRampToValueAtTime(0.0001, when + duration)
    src.connect(low).connect(gain).connect(master)

    const thump = ctx.createOscillator()
    thump.type = 'sine'
    thump.frequency.setValueAtTime(120 / Math.max(0.6, size), when)
    thump.frequency.exponentialRampToValueAtTime(38, when + 0.22)
    const thumpGain = ctx.createGain()
    thumpGain.gain.setValueAtTime(0.0001, when)
    thumpGain.gain.exponentialRampToValueAtTime(0.3 * volume, when + 0.01)
    thumpGain.gain.exponentialRampToValueAtTime(0.0001, when + 0.35)
    thump.connect(thumpGain).connect(master)
    thump.start(when)
    thump.stop(when + 0.36)
  }

  /** 잔불 「타닥」 — 짧은 고역 클릭을 흩뿌린다. */
  function crackle(when, volume) {
    for (let i = 0; i < 22; i += 1) {
      const at = when + Math.random() * 0.9
      const src = noiseSource(at, 0.035, 1.8)
      const high = ctx.createBiquadFilter()
      high.type = 'highpass'
      high.frequency.value = 2600
      const gain = ctx.createGain()
      gain.gain.setValueAtTime(0.14 * volume, at)
      gain.gain.exponentialRampToValueAtTime(0.0001, at + 0.035)
      src.connect(high).connect(gain).connect(master)
    }
  }

  const players = { launch, burst, crackle }

  return {
    /** 웹뷰가 소리를 막고 있으면 suspended 로 시작한다. 첫 재생 전에 깨운다. */
    resume() {
      if (ctx.state === 'suspended') ctx.resume()
    },
    /**
     * 엔진이 쌓아 둔 이벤트를 재생한다. delay 는 「빛보다 소리가 늦게 오는」 시간이라
     * setTimeout 이 아니라 오디오 시계에 예약한다 — 그래야 프레임이 밀려도 안 흔들린다.
     */
    play(events) {
      if (events.length === 0) return
      this.resume()
      const now = ctx.currentTime
      for (const event of events) {
        const player = players[event.type]
        if (player) player(now + (event.delay ?? 0), event.volume ?? 1, event.size ?? 1)
      }
    },
    setVolume(value) {
      master.gain.value = value
    },
  }
}
