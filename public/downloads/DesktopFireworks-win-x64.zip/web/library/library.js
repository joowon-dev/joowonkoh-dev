// 보관함. 올려 둔 이미지와 문구를 목록으로 관리하고, 고른 것을 쇼로 보낸다.
//
// **셸은 이 목록을 모른다.** 저장도 순서도 켬끔도 전부 여기(IndexedDB)에서 끝난다.
// 셸이 하는 일은 셋뿐이다 — 이 창 열기, 파일 고르기, 쇼 쪽 웹뷰로 전달하기.
// 웹뷰끼리는 직접 말할 수 없어서 전달만 셸을 거친다.

const DB_NAME = 'fireworks-library'
const STORE = 'items'

/** 브라우저로 열어 볼 때를 위한 대비. 셸에서는 window.sneakyLib 가 들어온다. */
const bridge = window.sneakyLib

const listEl = document.getElementById('list')
const textEl = document.getElementById('text')
const gapEl = document.getElementById('gap')
const countEl = document.getElementById('count')
const playEl = document.getElementById('play')

/** @type {{id: string, kind: 'image'|'text', name: string, dataUrl?: string, text?: string, on: boolean, order: number}[]} */
let items = []

// ── 저장 ────────────────────────────────────────────────────────────────────
//
// localStorage 를 안 쓰는 이유는 한도다. 512px PNG 하나가 60~300KB 라 5MB 로는 스무
// 장쯤이 한계다. IndexedDB 는 그 걱정이 없다.

function openDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1)
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(STORE)) {
        request.result.createObjectStore(STORE, { keyPath: 'id' })
      }
    }
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error)
  })
}

function withStore(mode, run) {
  return openDb().then((db) => new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, mode)
    const result = run(tx.objectStore(STORE))
    tx.oncomplete = () => resolve(result)
    tx.onerror = () => reject(tx.error)
  }))
}

async function loadAll() {
  const rows = await withStore('readonly', (store) => {
    const request = store.getAll()
    return new Promise((resolve) => { request.onsuccess = () => resolve(request.result) })
  })
  const all = await rows
  items = all.sort((a, b) => a.order - b.order)
}

const putAll = () => withStore('readwrite', (store) => {
  items.forEach((item, index) => {
    item.order = index
    store.put(item)
  })
})

const remove = (id) => withStore('readwrite', (store) => store.delete(id))

// ── 항목 ────────────────────────────────────────────────────────────────────

const newId = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`

async function addImage(name, dataUrl) {
  items.push({ id: newId(), kind: 'image', name, dataUrl, on: true, order: items.length })
  await putAll()
  render()
}

async function addText(text) {
  const trimmed = text.trim()
  if (trimmed.length === 0) return
  items.push({ id: newId(), kind: 'text', name: trimmed, text: trimmed, on: true, order: items.length })
  await putAll()
  render()
}

async function drop(id) {
  items = items.filter((item) => item.id !== id)
  await remove(id)
  await putAll()
  render()
}

// ── 그리기 ──────────────────────────────────────────────────────────────────

function render() {
  listEl.replaceChildren()

  if (items.length === 0) {
    const empty = document.createElement('li')
    empty.className = 'empty'
    empty.textContent = '아직 비어 있습니다. 이미지를 올리거나 문구를 적어 보세요.'
    listEl.append(empty)
  }

  for (const item of items) listEl.append(rowFor(item))

  const on = items.filter((item) => item.on).length
  countEl.textContent = items.length === 0 ? '' : `${on} / ${items.length} 개 선택`
  playEl.disabled = on === 0
}

function rowFor(item) {
  const row = document.createElement('li')
  row.className = item.on ? 'row' : 'row off'
  row.draggable = true
  row.dataset.id = item.id

  const grip = document.createElement('span')
  grip.className = 'grip'
  grip.textContent = '⠿'

  const check = document.createElement('input')
  check.type = 'checkbox'
  check.checked = item.on
  check.title = '쏠지 말지'
  check.addEventListener('change', async () => {
    item.on = check.checked
    await putAll()
    render()
  })

  const thumb = document.createElement('div')
  thumb.className = 'thumb'
  if (item.kind === 'image') thumb.style.backgroundImage = `url(${item.dataUrl})`
  else thumb.textContent = item.text.slice(0, 4)

  const name = document.createElement('div')
  name.className = 'name'
  name.append(item.name)
  const kind = document.createElement('small')
  kind.textContent = item.kind === 'image' ? '  이미지' : '  문구'
  name.append(kind)
  name.title = '눌러서 한 발 쏘기'
  name.addEventListener('click', () => play([item]))

  const kill = document.createElement('button')
  kill.className = 'kill'
  kill.textContent = '✕'
  kill.title = '지우기'
  kill.addEventListener('click', () => drop(item.id))

  row.append(grip, check, thumb, name, kill)
  return row
}

// ── 순서 바꾸기 ─────────────────────────────────────────────────────────────
//
// 끌고 있는 줄을 놓는 자리로 **곧바로 옮긴다**(자리를 미리 보여 준다). 놓을 때까지
// 아무 일도 안 일어나면 어디에 놓이는지 알 수가 없다.

let dragId = null

listEl.addEventListener('dragstart', (event) => {
  const row = event.target.closest('.row')
  if (!row) return
  dragId = row.dataset.id
  row.classList.add('dragging')
  event.dataTransfer.effectAllowed = 'move'
})

listEl.addEventListener('dragover', (event) => {
  event.preventDefault()
  const over = event.target.closest('.row')
  if (!over || dragId === null || over.dataset.id === dragId) return

  const from = items.findIndex((item) => item.id === dragId)
  const to = items.findIndex((item) => item.id === over.dataset.id)
  if (from < 0 || to < 0) return

  const [moved] = items.splice(from, 1)
  items.splice(to, 0, moved)
  render()
  listEl.querySelector(`[data-id="${dragId}"]`)?.classList.add('dragging')
})

listEl.addEventListener('dragend', async () => {
  dragId = null
  await putAll()
  render()
})

// ── 쏘기 ────────────────────────────────────────────────────────────────────

/**
 * 쇼로 보낸다. 간격은 여기서 세지 않고 **쇼 쪽 엔진의 예약 발사**에 맡긴다 —
 * 고정 타임스텝 위에서 도니까 간격이 정확하고, 이 창이 가려져도 어긋나지 않는다.
 */
function play(chosen) {
  const payload = {
    gap: Math.max(1, Number(gapEl.value) || 5),
    items: chosen.map((item) => ({
      id: item.id,
      kind: item.kind,
      text: item.text,
      dataUrl: item.dataUrl,
      on: true, // 골라서 보내는 것이므로 전부 켠 것으로 본다
    })),
  }
  if (bridge?.play) bridge.play(payload)
  else console.log('[보관함] 쇼가 없어 못 보냄:', payload.items.length, '개')
}

document.getElementById('addText').addEventListener('click', () => {
  addText(textEl.value)
  textEl.value = ''
})
textEl.addEventListener('keydown', (event) => {
  if (event.key !== 'Enter') return
  addText(textEl.value)
  textEl.value = ''
})

gapEl.addEventListener('change', () => localStorage.setItem('gap', gapEl.value))
const savedGap = localStorage.getItem('gap')
if (savedGap) gapEl.value = savedGap

playEl.addEventListener('click', () => play(items.filter((item) => item.on)))

// ── 이미지 올리기 ───────────────────────────────────────────────────────────
//
// 셸이 있으면 셸의 파일 선택창을 쓴다(긴 변 512px PNG 로 줄여서 돌려준다).
// 브라우저로 열어 볼 때는 페이지의 <input type=file> 로 대신한다.

document.getElementById('addImage').addEventListener('click', () => {
  if (bridge?.pickImage) bridge.pickImage()
  else pickInBrowser()
})

/** 셸이 파일을 골라 주면 이걸 부른다. */
window.__libAddImage = (name, dataUrl) => addImage(name, dataUrl)

function pickInBrowser() {
  const input = document.createElement('input')
  input.type = 'file'
  input.accept = 'image/*'
  input.addEventListener('change', () => {
    const file = input.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => addImage(file.name, String(reader.result))
    reader.readAsDataURL(file)
  })
  input.click()
}

loadAll().then(render).catch((error) => {
  console.error(`보관함을 못 읽었다 — ${error}`)
  render()
})
